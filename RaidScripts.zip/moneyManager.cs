﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moneyManager : MonoBehaviour
{
    startup start;

    public int coin;

    private bool coinIsCool;
    public float coinCoolTime = 2;

    public int coinGained;
    public int realCoin;
    public int coinMultiplier;

    // Start is called before the first frame update
    void Start()
    {
        coinMultiplier = 1;
        coin = 100;

        start = GetComponent<startup>();
    }

    // Update is called once per frame
    void Update()
    {
        if (start.setup)
            coinGain();
    }

    void coinGain()
    {
        if (coinIsCool == false)
        {
            realCoin = coinGained * coinMultiplier;
            coin += realCoin;

            StartCoroutine(coinCooler());
        }
    }

    IEnumerator coinCooler()
    {
        coinIsCool = true;

        yield return new WaitForSeconds(coinCoolTime);

        coinIsCool = false;
    }
}
