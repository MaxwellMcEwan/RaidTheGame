﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class kingdomTracker : MonoBehaviour
{
    public string kingdomName;

    public GameObject clanChoice;
    public GameObject inputChoice;
    Text DynastyName;
    GameObject canvas;
    GameObject canvasMain;

    public Text kingdomNameText;
    // Start is called before the first frame update
    void Awake()
    {
        canvas = FindObjectOfType<optionsMenu>().gameObject;
        canvasMain = canvas.transform.GetChild(1).gameObject;
        clanChoice = canvas.transform.GetChild(2).gameObject;
        inputChoice = canvas.transform.GetChild(3).gameObject;
        DynastyName = clanChoice.transform.GetChild(1).gameObject.GetComponent<Text>();


        if (Application.isEditor == false)
        {
            int IsFirst = PlayerPrefs.GetInt("IsFirst");
            if (IsFirst == 0 && SceneManager.GetActiveScene().buildIndex == 0)
            {
                //Do stuff on the first time
                PlayerPrefs.SetInt("IsFirst", 1);
                canvasMain.SetActive(false);
                clanChoice.SetActive(true);
                inputChoice.SetActive(false);
            }
            else
            {
                //Do stuff other times
                clanChoice.SetActive(false);
                inputChoice.SetActive(false);
                updateText(kingdomNameText);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void changeName()
    {
        Debug.Log("attempted change");
        canvas = FindObjectOfType<optionsMenu>().gameObject;
        canvasMain = canvas.transform.GetChild(1).gameObject;

        clanChoice = canvas.transform.GetChild(2).gameObject;
        inputChoice = canvas.transform.GetChild(3).gameObject;

        DynastyName = inputChoice.transform.GetChild(1).gameObject.GetComponent<Text>();

        canvasMain.SetActive(false);
        clanChoice.SetActive(true);
        inputChoice.SetActive(false);
    }

    public void upDateKingdomName(InputField input)
    {
        PlayerPrefs.SetString("kingdomName", input.text);
        DynastyName.text = input.text + " Dynasty";
    }

    public void enteredName(InputField input)
    {
        inputChoice.SetActive(false);

        canvasMain.SetActive(true);

        PlayerPrefs.SetString("kingdomName", input.text);
        DynastyName.text = input.text + " Dynasty";
    }

    public void updateText(Text kingdomText)
    {
        kingdomText.text = PlayerPrefs.GetString("kingdomName");
    }
}
