﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class archerTower : MonoBehaviour
{
    [HideInInspector]public int level;
    [HideInInspector]public bool construction;

    public GameObject arch0Con;
    public GameObject arch0;

    public GameObject arch1Con;
    public GameObject arch1;

    public GameObject arch2Con;
    public GameObject arch2;

    public GameObject arch3ConA;
    public GameObject arch3A;

    public GameObject arch3ConB;
    public GameObject arch3B;

    public GameObject tilledGround;

    GameObject currentTow;
    GameObject currentCon;

    public GameObject buildSmoke;
    GameObject destroySmoke;
    GameObject smoke;

    public GameObject destroyExplosion;

    [HideInInspector]public int health;
    public int maxHealth;

    [HideInInspector]public int damage;
    [HideInInspector]public float coolDown;

    [HideInInspector]public float lookRadius = 40;

    public bool choseAOrB;
    public bool recentlyHit;
    public bool repaired;
    
    Vector3 groundPos;
    archerHolder holder;

    public Material matNorm;
    public Material matSelected;
    MeshRenderer childMesh;

    bool playedBroken;
    // Start is called before the first frame update
    void Awake()
    {
        maxHealth = 10;
        health = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        if (health <= 0)
        {
            broken();
            return;
        }

        if (construction)
            return;
    }

    void levelController()
    {
        childMesh = currentTow.GetComponent<MeshRenderer>();
        switch (level)
        {
            case 0:

                maxHealth = 10;
                damage = 2;
                coolDown = 3;
                lookRadius = 30;

                break;

            case 1:

                maxHealth = 20;
                damage = 3;
                coolDown = 3;
                lookRadius = 35;

                break;

            case 2:

                maxHealth = 35;
                damage = 6;
                coolDown = 1.5f;
                lookRadius = 35;

                break;

            case 3:
                //B

                maxHealth = 40;
                damage = 9;
                coolDown = 1.5f;
                lookRadius = 45;

                break;

            case 4:
                //B

                maxHealth = 45;
                damage = 6;
                coolDown = .5f;
                lookRadius = 35;

                break;
        }
    }

    public void onSelect()
    {
        childMesh.material = matSelected;
    }

    public void onNorm()
    {
        childMesh.material = matNorm;
    }

    void broken()
    {
        FindObjectOfType<audioManager>().play("woodBreak");
        Instantiate(destroyExplosion, transform.position, transform.rotation, null);
        Destroy(gameObject);
        return;
    }


    public IEnumerator upgrade0()
    {
        
        GameObject ground = Instantiate(tilledGround, new Vector3(transform.position.x, transform.position.y + .38f, transform.position.z), transform.rotation);
        smoke = Instantiate(buildSmoke, transform);

        GameObject con0 = Instantiate(arch0Con, transform);

        construction = true;
        childMesh = con0.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(5);

        Destroy(con0);
   
        destroySmoke = smoke;
        StartCoroutine(smokeDestroyDelay());

        GameObject tow0 = Instantiate(arch0, transform);
        currentTow = tow0;

        construction = false;
        level = 0;

        holder = GetComponentInChildren<archerHolder>();
        holder.archersAdded = false;
        levelController();
    }

    public IEnumerator upgrade1()
    {
        smoke = Instantiate(buildSmoke, transform);

        construction = true;
        Destroy(currentTow);

        GameObject con1 = Instantiate(arch1Con, transform);
        childMesh = con1.GetComponent<MeshRenderer>();

        yield return new WaitForSeconds(10);

        construction = false;
        Destroy(con1);

        destroySmoke = smoke;
        StartCoroutine(smokeDestroyDelay());

        GameObject tow1 = Instantiate(arch1, transform);

        currentTow = tow1;

        level = 1;
        health = 20;

        holder = GetComponentInChildren<archerHolder>();
        holder.archersAdded = false;

        StartCoroutine(smokeDestroyDelay());
        levelController();
    }

    public IEnumerator upgrade2()
    {
        smoke = Instantiate(buildSmoke, transform);
        smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(250);
        destroySmoke = smoke;

        construction = true;
        Destroy(currentTow);

        GameObject con2 = Instantiate(arch2Con, transform);
        childMesh = con2.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(15);

        StartCoroutine(smokeDestroyDelay());

        construction = false;
        Destroy(con2);
        Destroy(smoke);

        GameObject tow2 = Instantiate(arch2, transform);

        currentTow = tow2;

        level = 2;
        health = 35;

        holder.archersAdded = false;
        levelController();
    }

    public IEnumerator upgrade3A()
    {
        smoke = Instantiate(buildSmoke, transform);
        smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(400);
        destroySmoke = smoke;

        choseAOrB = true;
        construction = true;
        Destroy(currentTow);

        GameObject con3A = Instantiate(arch3ConA, transform);
        childMesh = con3A.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(20);

        StartCoroutine(smokeDestroyDelay());

        construction = false;
        Destroy(con3A);

        GameObject tow3A = Instantiate(arch3A, transform);

        currentTow = tow3A;

        level = 3;
        holder = GetComponentInChildren<archerHolder>();
        holder.archersAdded = false;
        health = 40;
        levelController();
    }

    public IEnumerator upgrade3B()
    {
        smoke = Instantiate(buildSmoke, transform);
        smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(400);
        destroySmoke = smoke;

        choseAOrB = true;
        construction = true;
        Destroy(currentTow);

        GameObject con3B = Instantiate(arch3ConB, transform);
        childMesh = con3B.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(20);

        StartCoroutine(smokeDestroyDelay());

        construction = false;
        Destroy(con3B);

        GameObject tow3B = Instantiate(arch3B, transform);

        currentTow = tow3B;

        level = 4;
        health = 45;
        holder.archersAdded = false;
        levelController();
    }

    IEnumerator smokeDestroyDelay()
    {
        yield return new WaitForSeconds(1.3f);

        Destroy(destroySmoke);
    }

    public IEnumerator recentlyHitTimer()
    {
        recentlyHit = true;

        yield return new WaitForSeconds(5);

        recentlyHit = false;
    }

    public IEnumerator repair()
    {
        Destroy(currentTow);
        construction = true;
        smoke = Instantiate(buildSmoke, transform);

        switch (level)
        {
            case 0:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(50);

                GameObject con0 = Instantiate(arch0Con, transform);
                currentCon = con0;
                break;

            case 1:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(100);

                GameObject con1 = Instantiate(arch1Con, transform);
                currentCon = con1;
                break;

            case 2:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(150);

                GameObject con2 = Instantiate(arch2Con, transform);
                currentCon = con2;
                break;

            case 3:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(200);

                GameObject con3A = Instantiate(arch3ConA, transform);
                currentCon = con3A;
                break;

            case 4:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(200);

                GameObject con3B = Instantiate(arch3ConB, transform);
                currentCon = con3B;
                break;
        }

        yield return new WaitForSeconds((maxHealth - health) / 2);

        Destroy(currentCon);
        Destroy(smoke);

        switch (level)
        {
            case 0:
                GameObject tow0 = Instantiate(arch0, transform);

                currentTow = tow0;
                break;

            case 1:
                GameObject tow1 = Instantiate(arch1, transform);

                currentTow = tow1;
                break;

            case 2:
                GameObject tow2 = Instantiate(arch2, transform);

                currentTow = tow2;
                break;

            case 3:
                GameObject tow3A = Instantiate(arch3A, transform);

                currentTow = tow3A;
                break;

            case 4:

                GameObject tow3B = Instantiate(arch3B, transform);

                currentTow = tow3B;
                break;
        }

        construction = false;
        health = maxHealth;
        repaired = true;
    }
}
