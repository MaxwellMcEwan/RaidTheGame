﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class delayedDelete : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(destroyUs());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator destroyUs()
    {
        yield return new WaitForSeconds(15);

        Destroy(gameObject);
    }
}
