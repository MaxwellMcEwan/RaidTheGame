﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class towerWallController : MonoBehaviour
{
    public GameObject towerWall;

    int maxhealth;
    public int health;

    // Start is called before the first frame update
    void Start()
    {
        maxhealth = 10;
        health = maxhealth;

        Instantiate(towerWall, transform);
    }

    // Update is called once per frame
    void Update()
    {
        if (health <= 0)
            broken();
    }

    void broken()
    {
        Destroy(gameObject);
    }
}
