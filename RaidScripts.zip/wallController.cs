﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wallController : MonoBehaviour
{
    public GameObject tower;

    int maxHealth;
    public int health;

    public GameObject tilledGround;
    public GameObject towerTilledGrnd;
    public int form;

    public bool setNorm;
    GameObject ourWall;

    GameObject ground;
    MeshRenderer wallMesh;

    public GameObject dummyTower;
    MeshRenderer dummyMesh;

    GameObject ourDummy;
    towerSelector selector;
    // Start is called before the first frame update
    void Start()
    {
        selector = FindObjectOfType<towerSelector>();
        maxHealth = 10;
        health = maxHealth;

        ground = Instantiate(tilledGround, new Vector3(transform.position.x, transform.position.y + .38f, transform.position.z), transform.rotation);
        ourDummy = Instantiate(dummyTower, transform.position, transform.rotation);
        ourDummy.transform.parent = transform;

        dummyMesh = ourDummy.GetComponent<MeshRenderer>();
        dummyMesh.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (health <= 0)
            broken();

        if (setNorm)
        {
            switch (form)
            {
                case 0:
                    wallMesh.enabled = true;
                    dummyMesh.enabled = false;
                    break;
                case 1:
                    if (form == 1)
                    {
                        setNorm = false;
                        
                        Destroy(ourWall);
                        Destroy(ground);

                        ourWall = Instantiate(tower, transform.position, transform.rotation);
                        ourWall.transform.parent = transform;

                        ground = Instantiate(towerTilledGrnd, new Vector3(transform.position.x, transform.position.y + .38f, transform.position.z), transform.rotation);
                        dummyMesh.enabled = false;
                    }
                    break;
                case 2:
                    wallMesh.enabled = false;
                    dummyMesh.enabled = true;

                    if (!selector.wallActive)
                        form = 0;
                    break;
            }

        }
    }

    void broken()
    {
        FindObjectOfType<audioManager>().play("stoneBreak");

        Destroy(gameObject);
    }

    public void spawnOurselves(GameObject us, int type)
    {
        form = type;
        ourWall = Instantiate(us, transform.position, transform.rotation);
        ourWall.transform.parent = transform;

        if(form == 0)
        {
            wallMesh = ourWall.transform.GetChild(0).GetComponent<MeshRenderer>();
            setNorm = true;
        } else if(form == 1)
        {
            Destroy(ground);
            ground = Instantiate(towerTilledGrnd, new Vector3(transform.position.x, transform.position.y + .38f, transform.position.z), transform.rotation);
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.tag != "ground" && other.tag != "mound" && other.tag != "tree")
        {
            if (other.name == "feelerL" || other.name == "feelerR")
            {
                if (other.transform.rotation != transform.rotation)
                {
                    form = 1;
                }
                else
                {
                    Destroy(other);
                }
            }
            else  
            {
                if (other.name == "selectorFeelL" || other.name == "selectorFeelR")
                {
                    if (other.transform.rotation != transform.rotation && form == 0 && selector.wallActive)
                    {
                        form = 2;
                    }
                }
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.name == "selectorFeelL" || other.name == "selectorFeelR")
        {
            if (other.transform.rotation != transform.rotation && form == 2)
            {
                form = 0;
            }
        }
    }
}
