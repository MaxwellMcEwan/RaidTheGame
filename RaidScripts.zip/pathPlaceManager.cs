﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class pathPlaceManager : MonoBehaviour
{
    moneyManager money;
    startup start;
    placeManager placeManager;
    pathController path;

    public bool placingCast;
    public bool castCollididng;

    Camera cam;

    public int pathCost = 5;

    public GameObject castleMain;

    bool playedPlace;
    public GameObject pathGo;

    public GameObject pathCellParent;

    bool pathSelected;
    LayerMask pathMask;

    GameObject currentPath;

    public bool pathCooled;
    float pathCool = .2f;

    LayerMask groundMask;

    public bool buildMode;

    Vector2 mousePosPause;
    int pathVariation;

    int pathSide;

    public int lightMode;

    public int moneyCount;
    lightManager lightMan;
    bool activeLight;

    KeyCode placingPathKey = KeyCode.Q;

    KeyCode placingTow = KeyCode.X;

    KeyCode placingArchTow = KeyCode.Alpha1;
    KeyCode placingCanTow = KeyCode.Alpha2;
    KeyCode placingMageTow = KeyCode.Alpha3;
    KeyCode placingWallKey = KeyCode.Alpha4;

    // Start is called before the first frame update
    void Start()
    {
        if (FindObjectOfType<lightManager>() != null)
        {
            lightMan = FindObjectOfType<lightManager>();
            activeLight = true;
        }

        groundMask = LayerMask.GetMask("Ground");
        groundMask = 1 << 9;

        pathCooled = true;

        pathMask = LayerMask.GetMask("Path");
        pathMask = 1 << 11;

        placeManager = castleMain.GetComponent<placeManager>();
        money = castleMain.GetComponent<moneyManager>();
        start = castleMain.GetComponent<startup>();

        cam = Camera.main;
    }

    // Update is called once per frame
    void Update()
    {
        moneyCount = money.coin;

        if (!start.setup)
            return;

        if (activeLight)
        {
            if(lightMan.timeOfDay >= 18)
            {
                lightMode = 1;
            } else if (lightMan.timeOfDay < 17 && lightMan.timeOfDay > 5.5f)
            {
                lightMode = 0;
            }
            lightSwitch();
        }



        if (placingCast)
        {
            if (!playedPlace)
            {
                playedPlace = true;
                FindObjectOfType<audioManager>().play("placing");
            }

            if (Input.GetKeyUp(placingPathKey) || Input.GetKeyUp(placingArchTow) || Input.GetKeyUp(placingCanTow) 
                || Input.GetKeyUp(placingMageTow) || Input.GetKeyUp(placingWallKey) || Input.GetKeyUp(placingTow))
            {
                placingCast = false;
                playedPlace = false;
            }
        }
        else
        {
            if (Input.GetKeyUp(placingPathKey))
            {
                placingCast = true;
            }
        }
    }

    public void buildPath(GameObject runningPath)
    {
        if (money.coin >= pathCost)
        {
            money.coin -= pathCost;

            path = runningPath.GetComponent<pathController>();

            Vector3 newPathPos = path.selectedArrow.transform.position + path.pathVecAdd;
            path.selectedArrow = null;

            GameObject newPath = Instantiate(pathGo, newPathPos, new Quaternion(0, 0, 0, 0));
            newPath.transform.parent = gameObject.transform;

            newPath.GetComponent<pathController>().selected = true;

            switch (pathVariation)
            {
                case 0:
                    FindObjectOfType<audioManager>().play("pathBuild0");
                    pathVariation += 1;
                    break;
                case 1:
                    FindObjectOfType<audioManager>().play("pathBuild1");
                    pathVariation += 1;
                    break;
                case 2:
                    FindObjectOfType<audioManager>().play("pathBuild2");
                    pathVariation = 0;

                    if (pathSide == 1)
                    {
                        path.sideNum = 0;
                        pathSide = 0;
                    }
                    else
                    {
                        path.sideNum = 1;
                        pathSide += 1;
                    }
                    path.spawnPost();
                    break;
            }
        }
        else
        {
            runningPath.GetComponent<pathController>().selected = true;
        }
    }

    public void pathSwitched(GameObject setPath, GameObject oldPath)
    {
        oldPath.GetComponent<pathController>().selectedArrow = null;
        path = setPath.GetComponent<pathController>();

        path.selected = true;
    }

    public void switchToFirst(GameObject oldPath)
    {
        oldPath.GetComponent<pathController>().selected = false;
        FindObjectOfType<audioManager>().play("woosh");

        GameObject[] paths = GameObject.FindGameObjectsWithTag("path");

        foreach (GameObject thePath in paths)
        {
            if(thePath.transform.name == "firstCell")
            {
                thePath.GetComponent<pathController>().selected = true;
            }
        }
    }

    void lightSwitch()
    {
        lampPostController[] postCont = FindObjectsOfType<lampPostController>();

        foreach (lampPostController post in postCont)
        {
            if (!post.switching && post.ourMode != lightMode)
                post.changeLight(lightMode);
        }
    }

    public IEnumerator pathCooler()
    {
        pathCooled = false;
        yield return new WaitForSeconds(pathCool);
        pathCooled = true;
    }

}
