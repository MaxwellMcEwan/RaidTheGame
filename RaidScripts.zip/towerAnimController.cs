﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class towerAnimController : MonoBehaviour
{
    int towerType;

    public GameObject arrowBolt;
    public GameObject bloodPooler;

    towerAttack towerAtt;
    public GameObject canonFireSmoke;
    public bool selected;

    GameObject ourGem;
    RaycastHit arrowHit;

    Vector3 closestPos;
    Vector3 randomizedHitPoint;

    Vector3 hitPoint;
    Quaternion hitRot;

    LayerMask enemyLayer;
    // Start is called before the first frame update
    void Start()
    {
        enemyLayer = LayerMask.GetMask("Ground");
        enemyLayer = 1 << 12;

        towerType = -1;
        towerAtt = GetComponent<towerAttack>();
    }

    // Update is called once per frame
    void Update()
    {
        if (towerType == -1)
            findTowerType();

        controlAnims();
    }

    void controlAnims()
    {
        switch (towerType)
        {
            case 0:
                archerTower archer = GetComponent<archerTower>();
                if (GetComponentInChildren<archerHolder>() != null)
                {
                    if (GetComponentInChildren<archerHolder>().archersAdded && !archer.construction)
                    {
                        archerHolder holder = GetComponentInChildren<archerHolder>();
                        Animator archAnimator = holder.currentArcher.GetComponent<Animator>();

                        if (towerAtt.closestEnemy != null)
                        {
                            GameObject closestEnemy = towerAtt.closestEnemy.transform.GetChild(0).gameObject;
                            closestPos = new Vector3(closestEnemy.transform.position.x, closestEnemy.transform.position.y + 1.5f, closestEnemy.transform.position.z);
                            Vector3 ourPos = new Vector3(transform.position.x, transform.position.y + 2, transform.position.z);

                            Ray ray = new Ray(ourPos, closestPos - ourPos);
                            Debug.DrawRay(ourPos, closestPos - ourPos, Color.blue);

                            if (Physics.Raycast(ray, out arrowHit, Mathf.Infinity, enemyLayer))
                            {
                                if (arrowHit.collider.GetComponent<enemyAnimationController>() != null && arrowHit.transform.tag == "enemy")
                                {
                                    hitPoint = arrowHit.point;

                                    randomizedHitPoint = new Vector3(arrowHit.point.x, arrowHit.point.y + Random.Range(-1, 2), arrowHit.point.z);
                                }
                            }
                        }

                        int randomPlay = Random.Range(0, 3);

                        switch (archer.level)
                        {

                            case 0:

                                if (towerAtt.startAttackAnim)
                                {
                                    if (towerAtt.closestEnemy != null)
                                    {

                                        holder.sourceArcher0.Play();
                                        GameObject ourArrowGO = Instantiate(arrowBolt, randomizedHitPoint, Quaternion.LookRotation(arrowHit.normal));

                                        if (arrowHit.collider.transform != null)
                                        {
                                            if (arrowHit.collider.transform.childCount > 0)
                                            {
                                                ourArrowGO.transform.SetParent(arrowHit.collider.transform.GetChild(0).transform);
                                            }
                                        }

                                    }

                                    archAnimator.SetBool("firing", true);
                                    StartCoroutine(animOver());
                                }

                                break;

                            case 1:

                                if (towerAtt.startAttackAnim)
                                {
                                    if (towerAtt.closestEnemy != null)
                                    {
                                        holder.sourceArcher0.Play();
                                        GameObject ourArrowGO = Instantiate(arrowBolt, randomizedHitPoint, Quaternion.LookRotation(arrowHit.normal));

                                        if (arrowHit.collider.transform != null)
                                        {
                                            if (arrowHit.collider.transform.childCount > 0)
                                            {
                                                ourArrowGO.transform.SetParent(arrowHit.collider.transform.GetChild(0).transform);
                                            }
                                        }

                                        Destroy(ourArrowGO, 7);
                                    }
                                    archAnimator.SetBool("firing", true);
                                    StartCoroutine(animOver());

                                }

                                break;

                            case 2:

                                if (towerAtt.startAttackAnim)
                                {
                                    if (towerAtt.closestEnemy != null)
                                    {
                                        holder.sourceArcher0.Play();
                                        GameObject ourArrowGO = Instantiate(arrowBolt, randomizedHitPoint, Quaternion.LookRotation(arrowHit.normal));
                                        if (arrowHit.collider.transform != null)
                                        {
                                            if (arrowHit.collider.transform.childCount > 0)
                                            {
                                                ourArrowGO.transform.SetParent(arrowHit.collider.transform.GetChild(0).transform);
                                            }
                                        }
                                    }

                                    archAnimator.SetBool("firing", true);
                                    StartCoroutine(animOver());
                                }

                                break;

                            case 3:

                                if (towerAtt.startAttackAnim)
                                {
                                    if (towerAtt.closestEnemy != null)
                                    {
                                        holder.sourceArcher0.Play();
                                        GameObject ourArrowGO = Instantiate(arrowBolt, randomizedHitPoint, Quaternion.LookRotation(arrowHit.normal));
                                        if (arrowHit.collider.transform != null)
                                        {
                                            if (arrowHit.collider.transform.childCount > 0)
                                            {
                                                ourArrowGO.transform.SetParent(arrowHit.collider.transform.GetChild(0).transform);
                                            }
                                        }
                                    }

                                    archAnimator.SetBool("firing", true);
                                    StartCoroutine(animOver());
                                }

                                break;

                            case 4:

                                if (towerAtt.startAttackAnim)
                                {
                                    if (towerAtt.closestEnemy != null)
                                    {
                                        GameObject ourArrowGO = Instantiate(arrowBolt, randomizedHitPoint, Quaternion.LookRotation(arrowHit.normal));
                                        ourArrowGO.transform.SetParent(arrowHit.collider.transform.GetChild(0).transform);
                                    }

                                    holder.sourceArcher0.Play();
                                    archAnimator.SetBool("firing", true);
                                    if (holder.currentArcher != null)
                                    {
                                        if (towerAtt.closestEnemy != null)
                                        {
                                            holder.sourceArcher1.Play();
                                            GameObject ourArrowGO1 = Instantiate(arrowBolt, randomizedHitPoint, Quaternion.LookRotation(arrowHit.normal));
                                            if (arrowHit.collider.transform.childCount > 0)
                                            {
                                                ourArrowGO1.transform.SetParent(arrowHit.collider.transform.GetChild(0).transform);
                                            }

                                        }

                                        Animator archAnimator1 = holder.currentArcher1.GetComponent<Animator>();
                                        archAnimator1.SetBool("firing", true);
                                    }

                                    StartCoroutine(animOver());
                                }

                                break;
                        }

                    }
                }

                break;

            case 1:
                Animator canonAnimator = GetComponent<Animator>();
                Transform canonTrans = GetComponentInChildren<Transform>();

                if (towerAtt.startAttackAnim)
                {
                    canonAnimator.SetBool("firing", true);
                    StartCoroutine(animOver());

                    if (GetComponentInChildren<canonballController>() != null)
                    {
                        canonballController canonball = GetComponentInChildren<canonballController>();
                        canonball.StartCoroutine(canonball.bombDelay());
                    }
                }

                break;

            case 2:
                mageCrystalController crystalController = GetComponentInChildren<mageCrystalController>();
                Transform mageTrans = GetComponentInChildren<Transform>();


                if (towerAtt.startAttackAnim)
                {
                    crystalController.fired = true;
                    StartCoroutine(animOver());
                }

                break;
        }
    }

    IEnumerator animOver()
    {
        towerAtt.startAttackAnim = false;

        yield return new WaitForSeconds(towerAtt.animTime);

        switch (towerType)
        {
            case 0:
                archerTower archerTower = GetComponent<archerTower>();
                archerHolder holder = GetComponentInChildren<archerHolder>();
                if (holder != null)
                {
                    Animator archAnimator = holder.currentArcher.GetComponent<Animator>();

                    archAnimator.SetBool("firing", false);

                    if (archerTower.level == 4)
                    {
                        Animator archAnimator1 = holder.currentArcher1.GetComponent<Animator>();
                        archAnimator1.SetBool("firing", false);
                    }
                }

                break;

            case 1:
                Animator canonAnimator = GetComponent<Animator>();

                canonAnimator.SetBool("firing", false);
                break;

            case 2:
                break;
        }
    }

    void findTowerType()
    {
        if (GetComponent<archerTower>() != null)
        {
            towerType = 0;
        }
        else if (GetComponent<canonTower>() != null)
        {
            towerType = 1;
        }
        else if (GetComponent<mageTower>() != null)
        {
            towerType = 2;
        }
    }
}
