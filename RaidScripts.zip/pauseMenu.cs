﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class pauseMenu : MonoBehaviour
{
    public static bool gameIsPaused = false;
    public bool clickedButton;
    public bool clickedToggle;
    public GameObject pauseMenuUi;
    public GameObject optionsMenuUi;
    public GameObject rulesMenuUi;

    public placeManager place;
    public pathPlaceManager pathPlace;

    public AudioMixer mixer;

    private void Awake()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (gameIsPaused)
            {
                resume();
            }
            else
            {
                pause();
            }
        }
    }

    public void xButtonTriggered()
    {
        FindObjectOfType<audioManager>().play("uiXButtonClick");
    }

    public void directoryButtonTriggered()
    {
        FindObjectOfType<audioManager>().play("uiDirectButtonClick");
    }

    public void toggleTriggered()
    {
        FindObjectOfType<audioManager>().play("uiToggleClick");
    }

    public void resume()
    {
        pauseMenuUi.SetActive(false);
        optionsMenuUi.SetActive(false);
        rulesMenuUi.SetActive(false);
        Time.timeScale = 1f;
        gameIsPaused = false;

        FindObjectOfType<audioManager>().play("paperScrollB");
        mixer.SetFloat("musicPitch", 1f);
    }

    public void pause()
    {
        pauseMenuUi.SetActive(true);
        Time.timeScale = 0f;
        gameIsPaused = true;

        place.placing = false;
        pathPlace.placingCast = false;

        FindObjectOfType<audioManager>().play("paperScrollA");
        mixer.SetFloat("musicPitch", -2f);

        Cursor.lockState = CursorLockMode.Confined;
        Cursor.visible = true;
    }
}
