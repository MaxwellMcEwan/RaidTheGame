﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class enemySought : MonoBehaviour
{
    int ourType;

    public Material matNorm;
    public Material matTrans;

    MeshRenderer mainMesh;
    MeshRenderer hand;

    MeshRenderer legL;
    MeshRenderer legR;

    float exposeDist;
    float seekerDist;

    public bool exposed;
    // Start is called before the first frame update
    void Awake()
    {
        exposed = false;
        findOurType();
    }

    private void Start()
    {
        exposeDist = 20;

        switch (ourType)
        {
            case 2:
                mainMesh = GetComponent<MeshRenderer>();
                hand = transform.GetChild(0).GetComponent<MeshRenderer>();

                legL = null;
                legR = null;
                break;

            default:
                mainMesh = GetComponent<MeshRenderer>();
                hand = transform.GetChild(0).transform.GetComponent<MeshRenderer>();

                legL = transform.GetChild(1).transform.GetComponent<MeshRenderer>();
                legR = transform.GetChild(2).transform.GetComponent<MeshRenderer>();
                break;
        }
    }

    // Update is called once per frame
    void Update()
    {
        seekerDist = Vector3.Distance(FindClosestExpose().transform.position, transform.position);
        
        if(seekerDist <= exposeDist || exposed)
        {
            exposed = true;

            mainMesh.material = matNorm;
            hand.material = matNorm;

            if (legL != null && legR != null)
            {
                legL.material = matNorm;
                legR.material = matNorm;
            }
        }
        else
        {
            mainMesh.material = matTrans;
            hand.material = matTrans;

            if (legL != null && legR != null)
            {
                legL.material = matTrans;
                legR.material = matTrans;
            }
        }
    }

    public GameObject FindClosestExpose()
    {
        GameObject[] paths;
        GameObject[] towers;
        GameObject[] mainCastle;
        GameObject[] seekers;

        paths = GameObject.FindGameObjectsWithTag("path");
        towers = GameObject.FindGameObjectsWithTag("tower");
        mainCastle = GameObject.FindGameObjectsWithTag("mainCastle");

        seekers = paths.Concat(towers).Concat(mainCastle).ToArray();

        GameObject closest = null;
        float distance = Mathf.Infinity;
        Vector3 position = transform.position;

        foreach (GameObject go in seekers)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance && distance != 0)
            {
                closest = go;
                distance = curDistance;
            }
        }
        return closest;
    }

    void findOurType()
    {
        if (GetComponentInParent<swordmanController>() != null)
            ourType = 0;
        else if (GetComponentInParent<archerController>() != null)
            ourType = 1;
        else if (GetComponentInParent<mageController>() != null)
            ourType = 2;
    }
}
