﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class castleManager : MonoBehaviour
{
    [HideInInspector] public int level;
    [HideInInspector]public bool construction;

    public GameObject cast0Con;
    public GameObject cast0;

    public GameObject cast1Con;
    public GameObject cast1;

    public GameObject cast2Con;
    public GameObject cast2;

    public GameObject cast3ConA;
    public GameObject cast3A;

    public GameObject cast3ConB;
    public GameObject cast3B;

    GameObject currentCast;
    GameObject currentCon;

    public GameObject destroyExplosion;

    [HideInInspector] public int maxHealth;
    [HideInInspector] public int health;

    [HideInInspector] public bool choseAOrB;

    public GameObject tilledGround;

    [HideInInspector] public float lookRadius;
    captureCastleCont capture;
    moneyCollector collector;

    bool capCastle;

    public Material matNorm;
    public Material matSelected;
    MeshRenderer childMesh;
    MeshRenderer grandChild0Mesh;
    MeshRenderer grandChild1Mesh;
    // Start is called before the first frame update
    private void Awake()
    {
        collector = GetComponent<moneyCollector>();

        if (gameObject.tag == "tower")
        {
            maxHealth = 10;
            capture = GetComponent<captureCastleCont>();
            capCastle = true;
        }
        else
            maxHealth = 20;
            
        health = maxHealth;

        if (tag != "mainCastle")
            StartCoroutine(upgrade0());
    }

    // Update is called once per frame
    void Update()
    {
        if (health <= 0)
        {
            broken();
            return;
        }

        if(construction)
            return;
    }

    public void onSelect()
    {
        childMesh.material = matSelected;
        if (grandChild0Mesh != null && !construction)
        {
            grandChild0Mesh.material = matSelected;
            grandChild1Mesh.material = matSelected;
        }
    }

    public void onNorm()
    {
        childMesh.material = matNorm;
        if (grandChild0Mesh != null && !construction)
        {
            grandChild0Mesh.material = matNorm;
            grandChild1Mesh.material = matNorm;
        }
    }
    void levelController()
    {
        if (gameObject.tag == "tower")
        {
            GameObject mainC = gameObject.transform.GetChild(transform.childCount -1).gameObject;
            childMesh = mainC.GetComponent<MeshRenderer>();
            grandChild0Mesh = mainC.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>();
            grandChild1Mesh = mainC.transform.GetChild(1).gameObject.GetComponent<MeshRenderer>();

            moneyCollector money = GetComponent<moneyCollector>();

            switch (level)
            {
                case 0:
                    money.coinGained = 5;

                    maxHealth = 10;
                    break;

                case 1:
                    money.coinGained = 8;

                    maxHealth = 20;
                    break;

                case 2:
                    money.coinGained = 13;

                    maxHealth = 30;
                    break;
            }
        }
        else
        {
            childMesh = currentCast.GetComponent<MeshRenderer>();
            grandChild0Mesh = currentCast.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>();
            grandChild1Mesh = currentCast.transform.GetChild(1).gameObject.GetComponent<MeshRenderer>();

            moneyManager moneyMan = GetComponent<moneyManager>();

            switch (level)
            {
                case 0:
                    moneyMan.coinGained = 5;

                    maxHealth = 20;
                    break;

                case 1:
                    moneyMan.coinGained = 8;

                    maxHealth = 35;
                    break;

                case 2:
                    moneyMan.coinGained = 10;

                    maxHealth = 45;
                    break;

                case 3:
                    moneyMan.coinGained = 15;

                    maxHealth = 50;
                    break;

                case 4:
                    moneyMan.coinGained = 12;

                    maxHealth = 100;
                    break;
            }
        }
    }

    void broken()
    {
        if(!capCastle)
            Destroy(gameObject);
        else
        {
            Instantiate(destroyExplosion, transform.position, transform.rotation, null);
            Destroy(gameObject);
        }

    }

    public IEnumerator upgrade0()
    {
        level = -1;
        GameObject ground = Instantiate(tilledGround, new Vector3(transform.position.x, transform.position.y + .38f, transform.position.z), transform.rotation);
        GameObject con0 = Instantiate(cast0Con, transform);
        currentCon = con0;

        construction = true;

        childMesh = con0.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(0);

        Destroy(currentCon);

        currentCon.GetComponent<MeshRenderer>().enabled = false;

        GameObject tow0 = Instantiate(cast0, transform);

        currentCast = tow0;

        construction = false;
        level = 0;

        if (gameObject.tag == "tower")
            health = 10;
        else
            health = 20;

        levelController();
    }

    public IEnumerator upgrade1()
    {
        Destroy(currentCast);
        GameObject con1 = Instantiate(cast1Con, transform);
        currentCon = con1;

        construction = true;

        childMesh = con1.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(10);
        Destroy(currentCon);

        currentCon.GetComponent<MeshRenderer>().enabled = false;

        GameObject tow1 = Instantiate(cast1, transform);

        currentCast = tow1;

        construction = false;
        level = 1;

        if (gameObject.tag == "tower")
            health = 20;
        else
            health = 35;

        levelController();
    }

    public IEnumerator upgrade2()
    {
        Destroy(currentCast);

        GameObject con2 = Instantiate(cast2Con, transform);
        currentCon = con2;

        construction = true;

        childMesh = con2.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(10);
        Destroy(currentCon);

        currentCon.GetComponent<MeshRenderer>().enabled = false;

        GameObject tow2 = Instantiate(cast2, transform);

        currentCast = tow2;

        construction = false;
        level = 2;

        if (gameObject.tag == "tower")
            health = 30;
        else
            health = 45;

        levelController();
    }

    public IEnumerator upgrade3A()
    {
        Destroy(currentCast);

        choseAOrB = true;
        construction = true;

        GameObject con3A = Instantiate(cast3ConA, transform);
        currentCon = con3A;

        childMesh = con3A.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(20);
        Destroy(currentCon);

        GameObject tow3A = Instantiate(cast3A, transform);

        currentCast = tow3A;

        construction = false;
        level = 3;
        health = 50;

        levelController();
    }

    public IEnumerator upgrade3B()
    {
        Destroy(currentCast);

        choseAOrB = true;
        construction = true;

        GameObject con3B = Instantiate(cast3ConB, transform);
        currentCon = con3B;

        childMesh = con3B.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(20);
        Destroy(currentCon);
        
        GameObject tow3B = Instantiate(cast3B, transform);

        currentCast = tow3B;

        construction = false;
        level = 4;
        health = 60;

        levelController();
    }
}
