﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using System;
using UnityEngine.SceneManagement;

public class audioManager : MonoBehaviour
{
    public sound[] sounds;

    public static audioManager instance;
    public AudioMixer mixer;

    int currentScene;
    bool playingTrack;

    // Start is called before the first frame update
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);

        foreach (sound s in sounds)
        {
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip = s.clip;

            s.source.volume = s.volume;
            s.source.pitch = s.pitch;

            if (s.spatial)
            {
                s.source.spatialBlend = 1;
                s.source.rolloffMode = AudioRolloffMode.Linear;
                s.source.minDistance = 5;
                s.source.maxDistance = 60;
            }

            if (mixer.FindMatchingGroups(s.outputGroup)[0] != null)
            {
                s.source.outputAudioMixerGroup = mixer.FindMatchingGroups(s.outputGroup)[0];
            }
            else
            {
                Debug.Log("Matching group null");
            }
        }
    }
    
    public void play (string name)
    {
        sound s = Array.Find(sounds,  sound => sound.name == name);

        if (s == null)
        {
            Debug.Log("Sound with that name wasn't found >:)");
            return;
        }

        s.source.Play();
    }
}
