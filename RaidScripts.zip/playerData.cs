﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class playerData
{
    public int levelsCompleted;

    public playerData (saveLoad load)
    {
        levelsCompleted = load.levelsBeat;
    }
}
