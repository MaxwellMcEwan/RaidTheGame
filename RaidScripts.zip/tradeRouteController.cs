﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tradeRouteController : MonoBehaviour
{
    public bool connected;
    bool causedCelebrate;

    GameObject mainCastle;
    moneyManager money;
    // Start is called before the first frame update
    void Awake()
    {
        causedCelebrate = false;

        mainCastle = GameObject.FindGameObjectWithTag("mainCastle");

        money = mainCastle.GetComponent<moneyManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!causedCelebrate && connected)
        {
            money.coinMultiplier += 1;
            forceCelebrate();
            causedCelebrate = true;
            FindObjectOfType<audioManager>().play("cashRegister");
        }
    }

    public void forceCelebrate()
    {
        GameObject[] paths;
        pathController[] pathControllers;
        pathControllers = FindObjectsOfType<pathController>();

        paths = new GameObject[pathControllers.Length];
        for (int i = 0; i < paths.Length; i++)
            paths[i] = pathControllers[i].gameObject;
        Vector3 position = transform.position;

        foreach (GameObject go in paths)
        {
            go.GetComponent<pathController>().tradeCelebrate = true;
        }
    }
}
