﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class towerUpgrader : MonoBehaviour
{
    LayerMask towerMask;

    public GameObject mainCastle;

    placeManager placeManager;
    public moneyManager money;

    castleManager castleMain;

    public pathPlaceManager pathPlace;

    public GameObject selectedTower;

    bool towerSelected;
    bool onLastUp;

    Camera cam;

    public int towerType;
    int finalUp;

    public int upgrade0Cost = 25;
    public int upgrade1Cost = 80;
    public int upgrade2Cost = 175;

    public int castUpgrade0Cost = 200;
    public int castUpgrade1Cost = 550;
    public int castUpgrade2Cost = 1100;

    public int costToCapture;

    public bool fundingSecured;
    public bool startClose;
    public bool mainCastleUpgradedEnough;

    public int costToRepair;
    public bool repairing;

    float repairMultiplier;
    public int mainCastleLvlUp;

    bool playedSelect;

    public float captureCost;

    KeyCode destroyKey = KeyCode.T;
    KeyCode upgradeKey = KeyCode.F;
    KeyCode captureKey = KeyCode.C;
    KeyCode repairKey = KeyCode.R;

    KeyCode upgradeVar0 = KeyCode.Alpha5;
    KeyCode upgradeVar1 = KeyCode.Alpha6;

    KeyCode pathKey = KeyCode.Q;
    // Start is called before the first frame update
    void Start()
    {
        costToCapture = 100;
        towerMask = LayerMask.GetMask("Towers");
        towerMask = 1 << 13;

        captureCost = 100f;
        repairMultiplier = 1f;
        selectedTower = null;
        towerSelected = false;
        fundingSecured = true;
        castleMain = mainCastle.GetComponent<castleManager>();

        placeManager = mainCastle.GetComponent<placeManager>();
        money = mainCastle.GetComponent<moneyManager>();

        cam = Camera.main;
    }

    // Update is called once per frame
    void Update()
    {
        mainCastleLvlUp = castleMain.level + 2;

        if (!placeManager.placing)
        {
            selectTower();
        }
        else
        {
            towerColorChange();
            selectedTower = null;
        }

        if (towerSelected)
        {
            tower();
            if (Input.GetKey(pathKey))
            {
                towerColorChange();
                towerSelected = false;
                selectedTower = null;
                startClose = true;
            }
        }
        else
        {
            towerColorChange();
            startClose = true;
        }
    }

    void towerColorChange()
    {
        if (selectedTower != null)
        {
            switch (towerType)
            {
                case 0:
                    selectedTower.GetComponent<archerTower>().onNorm();
                    break;
                case 1:
                    selectedTower.GetComponent<canonTower>().onNorm();
                    break;
                case 2:
                    selectedTower.GetComponent<mageTower>().onNorm();
                    break;
                case 3:
                    selectedTower.GetComponent<castleManager>().onNorm();
                    break;
                case 4:
                    castleMain.GetComponent<castleManager>().onNorm();
                    break;
            }

        }
    }

    void selectTower()
    {
        if (Input.GetMouseButtonUp(0))
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, Mathf.Infinity, towerMask))
            {
                if (hit.collider.tag == "tower")
                {
                    pathPlace.placingCast = false;

                    if (hit.collider.gameObject == selectedTower)
                    {
                        towerColorChange();
                        selectedTower = null;
                        towerSelected = false;
                        startClose = true;
                    }
                    else
                    {
                        towerColorChange();

                        selectedTower = hit.collider.gameObject;

                        if (selectedTower.GetComponent<captureCastleCont>() != null)
                        {
                            if (!selectedTower.GetComponent<captureCastleCont>().exposed)
                            {
                                selectedTower = null;
                                towerSelected = false;
                            }
                            else
                            {
                                towerSelected = true;
                                towerType = 3;
                                FindObjectOfType<audioManager>().play("selectStone");
                            }
                        }
                        else
                        {
                            towerSelected = true;

                            if (selectedTower.GetComponent<archerTower>() != null)
                            {
                                towerType = 0;
                                FindObjectOfType<audioManager>().play("selectWood");
                            }
                            else if (selectedTower.GetComponent<canonTower>() != null)
                            {
                                towerType = 1;
                                FindObjectOfType<audioManager>().play("selectWood");
                            }
                            else if (selectedTower.GetComponent<mageTower>() != null)
                            {
                                towerType = 2;
                                FindObjectOfType<audioManager>().play("selectWood");
                            }
                        }
                    }
                }
                else if (hit.collider.gameObject == mainCastle)
                {
                    pathPlace.placingCast = false;

                    if (mainCastle == selectedTower)
                    {
                        towerColorChange();
                        startClose = true;
                        selectedTower = null;
                        towerSelected = false;
                    }
                    else
                    {
                        towerColorChange();
                        selectedTower = mainCastle;
                        towerSelected = true;
                        FindObjectOfType<audioManager>().play("selectStone");
                        towerType = 4;
                    }
                }
            }
        }
    }

    void tower()
    {
        if (selectedTower != null)
        {

            switch (towerType)
            {
                case 0:
                    archerTower archer = selectedTower.GetComponent<archerTower>();
                    archer.onSelect();

                    if (archer.level == 2 && !archer.choseAOrB)
                        onLastUp = true;
                    else
                        onLastUp = false;

                    if (castleMain.level >= archer.level + 1)
                        mainCastleUpgradedEnough = true;
                    else
                        mainCastleUpgradedEnough = false;

                    if (Input.GetKeyUp(upgradeKey) && !archer.construction)
                    {
                        if (castleMain.level >= archer.level + 1)
                        {
                            switch (archer.level)
                            {
                                case 0:

                                    if (money.coin >= upgrade0Cost)
                                    {
                                        archer.StartCoroutine(archer.upgrade1());
                                        money.coin -= upgrade0Cost;

                                        FindObjectOfType<audioManager>().play("coinBuild");
                                    }
                                    else
                                    {
                                        fundingSecured = false;
                                    }


                                    break;

                                case 1:

                                    if (money.coin >= upgrade1Cost)
                                    {
                                        archer.StartCoroutine(archer.upgrade2());
                                        money.coin -= upgrade1Cost;

                                        FindObjectOfType<audioManager>().play("coinBuild");
                                    }
                                    else
                                    {
                                        fundingSecured = false;
                                    }

                                    break;
                            }
                        }
                    }

                    if (onLastUp)
                    {
                        if (Input.GetKeyUp(upgradeVar0))
                        {
                            if (money.coin >= upgrade2Cost)
                            {
                                archer.StartCoroutine(archer.upgrade3A());
                                money.coin -= upgrade2Cost;
                                onLastUp = false;

                                FindObjectOfType<audioManager>().play("coinBuild");
                            }
                        }
                        else if (Input.GetKeyUp(upgradeVar1))
                        {
                            if (money.coin >= upgrade2Cost)
                            {
                                archer.StartCoroutine(archer.upgrade3B());
                                money.coin -= upgrade2Cost;
                                onLastUp = false;

                                FindObjectOfType<audioManager>().play("coinBuild");
                            }
                        }
                    }

                    if (Input.GetKey(destroyKey) && !archer.construction)
                    {
                        startClose = true;
                        towerSelected = false;
                        selectedTower = null;
                        archer.health = -10;
                    }

                    costToRepair = Mathf.RoundToInt((archer.maxHealth - archer.health) * repairMultiplier);


                    if (Input.GetKeyUp(repairKey))
                    {
                        if (archer.health < archer.maxHealth)
                        {
                            if (!archer.recentlyHit)
                            {
                                if (money.coin >= costToRepair && !archer.construction)
                                {
                                    archer.StartCoroutine(archer.repair());

                                    repairing = true;

                                    money.coin -= costToRepair;
                                }
                            }
                        }
                    }

                    break;

                case 1:
                    canonTower canon = selectedTower.GetComponent<canonTower>();

                    canon.onSelect();

                    if (canon.level == 2 && !canon.choseAOrB)
                        onLastUp = true;
                    else
                        onLastUp = false;

                    if (castleMain.level >= canon.level + 1)
                        mainCastleUpgradedEnough = true;
                    else
                        mainCastleUpgradedEnough = false;

                    if (Input.GetKeyUp(upgradeKey) && !canon.construction)
                    {
                        if (castleMain.level >= canon.level + 1)
                        {
                            switch (canon.level)
                            {
                                case 0:

                                    if (money.coin >= upgrade0Cost)
                                    {
                                        canon.StartCoroutine(canon.upgrade1());
                                        money.coin -= upgrade0Cost;

                                        FindObjectOfType<audioManager>().play("coinBuild");
                                    }
                                    else
                                    {
                                        fundingSecured = false;
                                    }

                                    break;

                                case 1:

                                    if (money.coin >= upgrade1Cost)
                                    {
                                        canon.StartCoroutine(canon.upgrade2());
                                        money.coin -= upgrade1Cost;

                                        FindObjectOfType<audioManager>().play("coinBuild");
                                    }
                                    else
                                    {
                                        fundingSecured = false;
                                    }

                                    break;
                            }
                        }
                    }

                    if (onLastUp)
                    {
                        if (Input.GetKeyUp(upgradeVar0))
                        {
                            if (money.coin >= upgrade2Cost)
                            {
                                canon.StartCoroutine(canon.upgrade3A());
                                money.coin -= upgrade2Cost;
                                onLastUp = false;

                                FindObjectOfType<audioManager>().play("coinBuild");
                            }
                        }
                        else if (Input.GetKeyUp(upgradeVar1))
                        {
                            if (money.coin >= upgrade2Cost)
                            {
                                canon.StartCoroutine(canon.upgrade3B());
                                money.coin -= upgrade2Cost;
                                onLastUp = false;

                                FindObjectOfType<audioManager>().play("coinBuild");
                            }
                        }
                    }

                    if (Input.GetKey(destroyKey) && !canon.construction)
                    {
                        startClose = true;
                        towerSelected = false;
                        selectedTower = null;
                        canon.health = 0;
                    }

                    costToRepair = Mathf.RoundToInt((canon.maxHealth - canon.health) * repairMultiplier);

                    if (Input.GetKeyUp(repairKey))
                    {
                        if (canon.health < canon.maxHealth)
                        {
                            if (!canon.recentlyHit)
                            {
                                if (money.coin >= costToRepair && !canon.construction)
                                {
                                    canon.StartCoroutine(canon.repair());

                                    repairing = true;

                                    money.coin -= costToRepair;
                                }
                            }
                        }
                    }

                    break;

                case 2:

                    mageTower mage = selectedTower.GetComponent<mageTower>();

                    mage.onSelect();

                    if (mage.level == 2 && !mage.choseAOrB)
                        onLastUp = true;
                    else
                        onLastUp = false;

                    if (castleMain.level >= mage.level + 1)
                        mainCastleUpgradedEnough = true;
                    else
                        mainCastleUpgradedEnough = false;

                    if (Input.GetKeyUp(upgradeKey) && !mage.construction)
                    {
                        if (castleMain.level >= mage.level + 1)
                        {
                            switch (mage.level)
                            {
                                case 0:

                                    if (money.coin >= upgrade0Cost)
                                    {
                                        mage.StartCoroutine(mage.upgrade1());
                                        money.coin -= upgrade0Cost;

                                        FindObjectOfType<audioManager>().play("coinBuild");
                                    }
                                    else
                                    {
                                        fundingSecured = false;
                                    }

                                    break;

                                case 1:

                                    if (money.coin >= upgrade1Cost)
                                    {
                                        mage.StartCoroutine(mage.upgrade2());
                                        money.coin -= upgrade1Cost;

                                        FindObjectOfType<audioManager>().play("coinBuild");
                                    }
                                    else
                                    {
                                        fundingSecured = false;
                                    }
                                    break;
                            }
                        }
                    }

                    if (onLastUp)
                    {
                        if (Input.GetKeyUp(upgradeVar0))
                        {
                            if (money.coin >= upgrade2Cost)
                            {
                                mage.StartCoroutine(mage.upgrade3A());
                                money.coin -= upgrade2Cost;
                                onLastUp = false;

                                FindObjectOfType<audioManager>().play("coinBuild");
                            }
                        }
                        else if (Input.GetKeyUp(upgradeVar1))
                        {
                            if (money.coin >= upgrade2Cost)
                            {
                                mage.StartCoroutine(mage.upgrade3B());
                                money.coin -= upgrade2Cost;
                                onLastUp = false;

                                FindObjectOfType<audioManager>().play("coinBuild");
                            }
                        }
                    }

                    if (Input.GetKey(destroyKey) && !mage.construction)
                    {
                        startClose = true;
                        towerSelected = false;
                        selectedTower = null;
                        mage.health = 0;
                    }

                    costToRepair = Mathf.RoundToInt((mage.maxhealth - mage.health) * repairMultiplier);

                    if (Input.GetKeyUp(repairKey))
                    {
                        if (mage.health < mage.maxhealth)
                        {
                            if (!mage.recentlyHit)
                            {
                                if (money.coin >= costToRepair && !mage.construction)
                                {
                                    mage.StartCoroutine(mage.repair());

                                    repairing = true;

                                    money.coin -= costToRepair;
                                }
                            }
                        }
                    }

                    break;

                case 3:
                    castleManager castle = selectedTower.GetComponent<castleManager>();
                    captureCastleCont captureCont = selectedTower.GetComponent<captureCastleCont>();
                    castle.onSelect();

                    if (castle.level == 2 && !castle.choseAOrB)
                        onLastUp = true;
                    else
                        onLastUp = false;

                    if (castleMain.level >= castle.level + 1)
                        mainCastleUpgradedEnough = true;
                    else
                        mainCastleUpgradedEnough = false;

                    if (!captureCont.captured)
                    {
                        if (Input.GetKeyUp(captureKey) && money.coin >= costToCapture)
                        {
                            captureCont.captured = true;
                            money.coin -= costToCapture;
                        }
                        else if (Input.GetKeyUp(captureKey) && money.coin < costToCapture)
                        {
                            fundingSecured = false;
                        }
                    }

                    if (Input.GetKeyUp(upgradeKey) && !castle.construction && captureCont.captured)
                    {
                        if (castleMain.level >= castle.level + 1)
                        {
                            switch (castle.level)
                            {
                                case 0:

                                    if (money.coin >= castUpgrade0Cost)
                                    {
                                        castle.StartCoroutine(castle.upgrade1());
                                        money.coin -= castUpgrade0Cost;

                                        FindObjectOfType<audioManager>().play("coinBuild");
                                    }
                                    else
                                    {
                                        fundingSecured = false;
                                    }

                                    break;

                                case 1:

                                    if (money.coin >= castUpgrade1Cost)
                                    {
                                        castle.StartCoroutine(castle.upgrade2());
                                        money.coin -= castUpgrade1Cost;

                                        FindObjectOfType<audioManager>().play("coinBuild");
                                    }
                                    else
                                    {
                                        fundingSecured = false;
                                    }

                                    break;
                            }
                        }
                    }
                    break;

                case 4:
                    castleMain.onSelect();

                    if (castleMain.level == 2 && !castleMain.choseAOrB)
                        onLastUp = true;
                    else
                        onLastUp = false;

                    if (Input.GetKeyUp(upgradeKey) && !castleMain.construction)
                    {
                        switch (castleMain.level)
                        {
                            case 0:

                                if (money.coin >= castUpgrade0Cost)
                                {
                                    castleMain.StartCoroutine(castleMain.upgrade1());
                                    money.coin -= castUpgrade0Cost;
                                    FindObjectOfType<audioManager>().play("coinBuild");
                                }
                                else
                                {
                                    fundingSecured = false;
                                }

                                break;

                            case 1:

                                if (money.coin >= castUpgrade1Cost)
                                {
                                    castleMain.StartCoroutine(castleMain.upgrade2());
                                    money.coin -= castUpgrade1Cost;
                                    FindObjectOfType<audioManager>().play("coinBuild");
                                }
                                else
                                {
                                    fundingSecured = false;
                                }

                                break;
                        }
                    }

                    if (onLastUp)
                    {
                        if (Input.GetKeyUp(upgradeVar0))
                        {
                            if (money.coin >= castUpgrade2Cost)
                            {
                                castleMain.StartCoroutine(castleMain.upgrade3A());
                                money.coin -= castUpgrade2Cost;
                                FindObjectOfType<audioManager>().play("coinBuild");
                                onLastUp = false;
                            }
                        }
                        else if (Input.GetKeyUp(upgradeVar1))
                        {
                            if (money.coin >= castUpgrade2Cost)
                            {
                                castleMain.StartCoroutine(castleMain.upgrade3B());
                                money.coin -= castUpgrade2Cost;
                                FindObjectOfType<audioManager>().play("coinBuild");
                                onLastUp = false;
                            }
                        }
                    }

                    break;
            }
        }
    }
}
