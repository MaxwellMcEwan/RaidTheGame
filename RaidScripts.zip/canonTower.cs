﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class canonTower : MonoBehaviour
{
    [HideInInspector] public int level;
    [HideInInspector] public bool construction;

    public GameObject canon0Con;
    public GameObject canon0;

    public GameObject canon1Con;
    public GameObject canon1;

    public GameObject canon2Con;
    public GameObject canon2;

    public GameObject canon3ConA;
    public GameObject canon3A;

    public GameObject canon3ConB;
    public GameObject canon3B;

    GameObject currentTow;
    GameObject currentCon;

    [HideInInspector] public int health;
    [HideInInspector] public int maxHealth;

    [HideInInspector] public int damage;
    [HideInInspector] public float coolDown;

    [HideInInspector] public float lookRadius = 60;

    public GameObject buildSmoke;
    GameObject destroySmoke;
    GameObject smoke;
    public GameObject destroyExplosion;

    public GameObject tilledGround;

    [HideInInspector] public bool choseAOrB;
    [HideInInspector] public bool recentlyHit;

    public Material matNorm;
    public Material matSelected;
    MeshRenderer childMesh;
    MeshRenderer grandChildMesh;
    // Start is called before the first frame update
    void Start()
    {
        maxHealth = 10;
        health = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        if (health <= 0)
            broken();

        if (construction)
            return;
    }

    public void onSelect()
    {
        childMesh.material = matSelected;
        if (grandChildMesh != null && !construction)
            grandChildMesh.material = matSelected;
    }

    public void onNorm()
    {
        childMesh.material = matNorm;
        if(grandChildMesh != null && !construction)
            grandChildMesh.material = matNorm;
    }

    void levelController()
    {
        childMesh = currentTow.GetComponent<MeshRenderer>();
        grandChildMesh = currentTow.transform.GetChild(0).GetComponent<MeshRenderer>();

        switch (level)
        {
            case 0:

                maxHealth = 10;
                damage = 7;
                coolDown = 5;
                lookRadius = 35;

                break;

            case 1:

                maxHealth = 15;
                damage = 7;
                coolDown = 4;
                lookRadius = 40;

                break;

            case 2:

                maxHealth = 25;
                damage = 8;
                coolDown = 4;
                lookRadius = 50;

                break;

            case 3:

                maxHealth = 30;
                damage = 12;
                coolDown = 6;
                lookRadius = 80;

                break;

            case 4:

                maxHealth = 35;
                damage = 7;
                coolDown = 2;
                lookRadius = 60;

                break;
        }
    }

    void broken()
    {
        FindObjectOfType<audioManager>().play("woodBreak");
        Instantiate(destroyExplosion, transform.position, transform.rotation, null);
        Destroy(gameObject);
        return;
    }

    public IEnumerator upgrade0()
    {
        GameObject ground = Instantiate(tilledGround, new Vector3(transform.position.x, transform.position.y + .38f, transform.position.z), transform.rotation);
        smoke = Instantiate(buildSmoke, transform);

        GameObject con0 = Instantiate(canon0Con, transform);

        construction = true;

        childMesh = con0.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(5);

        Destroy(con0);

        destroySmoke = smoke;
        StartCoroutine(smokeDestroyDelay());

        GameObject tow0 = Instantiate(canon0, transform);

        currentTow = tow0;

        construction = false;
        level = 0;
        levelController();
    }

    public IEnumerator upgrade1()
    {
        construction = true;
        Destroy(currentTow);

        GameObject con1 = Instantiate(canon1Con, transform);

        childMesh = con1.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(10);

        construction = false;
        Destroy(con1);

        GameObject tow1 = Instantiate(canon1, transform);

        currentTow = tow1;

        level = 1;
        health = 15;
        levelController();
    }

    public IEnumerator upgrade2()
    {
        construction = true;
        Destroy(currentTow);

        GameObject con2 = Instantiate(canon2Con, transform);

        childMesh = con2.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(15);

        construction = false;
        Destroy(con2);

        GameObject tow2 = Instantiate(canon2, transform);

        currentTow = tow2;

        level = 2;
        health = 25;
        levelController();
    }

    public IEnumerator upgrade3A()
    {
        choseAOrB = true;
        construction = true;
        Destroy(currentTow);

        GameObject con3A = Instantiate(canon3ConA, transform);

        childMesh = con3A.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(25);

        construction = false;
        Destroy(con3A);

        GameObject tow3A = Instantiate(canon3A, transform);

        currentTow = tow3A;

        level = 3;
        health = 30;
        levelController();
    }

    public IEnumerator upgrade3B()
    {
        choseAOrB = true;
        construction = true;
        Destroy(currentTow);

        GameObject con3B = Instantiate(canon3ConB, transform);

        childMesh = con3B.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(25);

        construction = false;
        Destroy(con3B);

        GameObject tow3B = Instantiate(canon3B, transform);

        currentTow = tow3B;

        level = 4;
        health = 35;
        levelController();
    }

    IEnumerator smokeDestroyDelay()
    {
        yield return new WaitForSeconds(1.3f);

        Destroy(destroySmoke);
    }

    public IEnumerator recentlyHitTimer()
    {
        recentlyHit = true;

        yield return new WaitForSeconds(5);

        recentlyHit = false;
    }

    public IEnumerator repair()
    {
        Destroy(currentTow);
        construction = true;
        smoke = Instantiate(buildSmoke, transform);

        switch (level)
        {
            case 0:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(50);

                GameObject con0 = Instantiate(canon0Con, transform);
                currentCon = con0;
                break;

            case 1:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(100);

                GameObject con1 = Instantiate(canon1Con, transform);
                currentCon = con1;
                break;

            case 2:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(150);

                GameObject con2 = Instantiate(canon2Con, transform);
                currentCon = con2;
                break;

            case 3:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(200);

                GameObject con3A = Instantiate(canon3ConA, transform);
                currentCon = con3A;
                break;

            case 4:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(200);

                GameObject con3B = Instantiate(canon3ConB, transform);
                currentCon = con3B;
                break;
        }

        yield return new WaitForSeconds((maxHealth - health) / 2);

        Destroy(currentCon);
        Destroy(smoke);

        switch (level)
        {
            case 0:
                GameObject tow0 = Instantiate(canon0, transform);

                currentTow = tow0;
                break;

            case 1:
                GameObject tow1 = Instantiate(canon1, transform);

                currentTow = tow1;
                break;

            case 2:
                GameObject tow2 = Instantiate(canon2, transform);

                currentTow = tow2;
                break;

            case 3:
                GameObject tow3A = Instantiate(canon3A, transform);

                currentTow = tow3A;
                break;

            case 4:

                GameObject tow3B = Instantiate(canon3B, transform);

                currentTow = tow3B;
                break;
        }

        construction = false;
        health = maxHealth;
    }
}
