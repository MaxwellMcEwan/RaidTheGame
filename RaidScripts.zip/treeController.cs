﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class treeController : MonoBehaviour
{
    collisionCheck collision;

    public bool delaying;

    Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        delaying = false;

        collision = GetComponent<collisionCheck>();
        anim = GetComponentInChildren<Animator>();
    }

    public void collisionUpdate()
    {
        if (!collision.colliding && !anim.GetBool("up"))
        {
            anim.SetBool("up", true);
        }
        else if (collision.colliding && anim.GetBool("up"))
        {
            anim.SetBool("up", false);
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "path" && other.tag != "mound" || other.tag == "tower" && other.tag != "mound")
        {
            Destroy(gameObject, 2f);
        }
    }
}
