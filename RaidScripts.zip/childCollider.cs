﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class childCollider : MonoBehaviour
{
    collisionCheck check;

    MeshRenderer meshRend;
    MeshRenderer usMeshRend;
    float duration = 4;

    public Material mat0;
    public Material matRed;

    // Start is called before the first frame update
    void Start()
    {
        check = GetComponentInParent<collisionCheck>();
        meshRend = GetComponentInParent<MeshRenderer>();

        usMeshRend = GetComponent<MeshRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (check.meshActive)
            usMeshRend.enabled = true;
        else
            usMeshRend.enabled = false;

        if (check.colliding || check.underCount)
            meshRend.material.Lerp(mat0, matRed, duration);
        else if (meshRend.material != mat0)
            meshRend.material.Lerp(matRed, mat0, duration);
    }
}
