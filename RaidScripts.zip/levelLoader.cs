﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
using UnityEngine.UI;

public class levelLoader : MonoBehaviour
{
    public Animator transistion;
    public Text loadingText;

    float transistionTime = 4;
    public AudioMixer mixer;

    int jumpNum = 1;

    public GameObject EveredTxt;
    public GameObject WolffTxt;
    public GameObject RagnarTxt;
    // Start is called before the first frame update
    void Awake()
    {
        if (SceneManager.GetActiveScene().buildIndex != 1 && SceneManager.GetActiveScene().buildIndex != 0)
        {
            FindObjectOfType<audioManager>().play("curtainOpen");
        }
        else if (SceneManager.GetActiveScene().buildIndex != 0)
        {
            switch (PlayerPrefs.GetInt("tribe"))
            {
                case 0:
                    EveredTxt.SetActive(true);
                    WolffTxt.SetActive(false);
                    RagnarTxt.SetActive(false);
                    break;
                case 1:
                    EveredTxt.SetActive(false);
                    WolffTxt.SetActive(true);
                    RagnarTxt.SetActive(false);

                    break;
                case 2:
                    EveredTxt.SetActive(false);
                    WolffTxt.SetActive(false);
                    RagnarTxt.SetActive(true);

                    break;
            }
        }
    }

    private void Start()
    {

    }
    // Update is called once per frame
    void Update()
    {
        
    }

    public void toMain()
    {
        StartCoroutine(loadLevel(1));
        Time.timeScale = 1f;

        mixer.SetFloat("musicPitch", 1f);

        loadingText.gameObject.SetActive(true);
        loadingText.text = "Later yo!";

        if(findCurrentBuild() > 18)
        {
            PlayerPrefs.SetInt("beatLevels", 0);
        }
    }

    public void newGameSetup()
    {
        int timeToDelay = 3;
        PlayerPrefs.DeleteAll();
        PlayerPrefs.SetInt("IsFirst", 0);
        Invoke("delayedTrumpet", 1);
        Invoke("secretNext", timeToDelay);
    }

    void delayedTrumpet()
    {
        FindObjectOfType<audioManager>().play("trumpetOpen");
    }

    void secretNext()
    {
        SceneManager.LoadScene(1);
    }

    public void playForest()
    {
       StartCoroutine(loadLevel(SceneManager.GetActiveScene().buildIndex + 1));
    }

    public void playNext()
    {
        FindObjectOfType<optionsMenu>().gameObject.SetActive(false);
        if (findCurrentBuild() != 18)
        {
            Debug.Log(findCurrentBuild());
            StartCoroutine(loadLevel(SceneManager.GetActiveScene().buildIndex + 1));
            loadingText.text = "Loading...";
        } else
        {
            PlayerPrefs.SetInt("finale", 1);
            loadingText.text = "Prepare...";

            switch (PlayerPrefs.GetInt("tribe"))
            {
                case 0:
                    StartCoroutine(loadLevel(SceneManager.GetActiveScene().buildIndex + 3));

                    break;
                case 1:
                    StartCoroutine(loadLevel(SceneManager.GetActiveScene().buildIndex + 2));

                    break;
                case 2:
                    StartCoroutine(loadLevel(SceneManager.GetActiveScene().buildIndex + 1));

                    break;
            }
        }
    }

    public void updateTag()
    {
        switch (PlayerPrefs.GetInt("tribe"))
        {
            case 0:
                EveredTxt.SetActive(true);
                WolffTxt.SetActive(false);
                RagnarTxt.SetActive(false);
                break;
            case 1:
                EveredTxt.SetActive(false);
                WolffTxt.SetActive(true);
                RagnarTxt.SetActive(false);

                break;
            case 2:
                EveredTxt.SetActive(false);
                WolffTxt.SetActive(false);
                RagnarTxt.SetActive(true);

                break;
        }
    }
    IEnumerator loadLevel(int levelIndex)
    {
        transistion.SetTrigger("start");
        FindObjectOfType<audioManager>().play("curtainClose");
        loadingText.gameObject.SetActive(true);
        Invoke("playKeySound", .8f);

        if (SceneManager.GetActiveScene().buildIndex != 0)
        {
            musicManager musicMan = FindObjectOfType<musicManager>();
            musicMan.fadeOutAudio();

            yield return new WaitForSeconds(transistionTime);

            transistion.ResetTrigger("start");

            musicMan.ourBuildIndex = levelIndex;
            musicMan.fadeInAudio();

            SceneManager.LoadScene(levelIndex);
        }
        else
        {
            yield return new WaitForSeconds(transistionTime);

            transistion.ResetTrigger("start");

            SceneManager.LoadScene(levelIndex);

        }

    }

    public void PlayCampaign()
    {

        int campaginProg = FindObjectOfType<saveLoad>().levelsBeat + jumpNum;
        Debug.Log(FindObjectOfType<saveLoad>().levelsBeat);
        if (campaginProg != 1)
        {
            if (campaginProg <= 18)
            {
                StartCoroutine(loadLevel(campaginProg));
            }
            else
            {
                int nextLev = 0;
                switch (PlayerPrefs.GetInt("tribe"))
                {
                    case 0:
                        nextLev = 20;
                        break;
                    case 1:
                        nextLev = 19;
                        break;
                    case 2:
                        nextLev = 18;
                        break;
                }

                StartCoroutine(loadLevel(nextLev));
            }
        }
        else
        {
            StartCoroutine(loadLevel(2));
        }
    }

    void playKeySound()
    {
        FindObjectOfType<audioManager>().play("loadingKeys");
    }

    public int findCurrentBuild()
    {
        int currentScene =  SceneManager.GetActiveScene().buildIndex;
        return currentScene;
    }
}
