﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class canonball : MonoBehaviour
{
    float explosionRadius = 5;
    float explosionDamage = .7f;
    public GameObject impactEffect;

    bool splashed;
    AudioSource audioSource;
    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    void splash()
    {
        splashed = true;
        GameObject spawnedImpactEffect = Instantiate(impactEffect, transform.position, transform.rotation);
        float randomScaleAdd = Random.Range(0, 2);
        spawnedImpactEffect.transform.localScale += new Vector3(randomScaleAdd, randomScaleAdd, randomScaleAdd);
        audioSource.Play();

        GameObject[] gos;
        gos = GameObject.FindGameObjectsWithTag("enemy");
        Vector3 position = transform.position;
        foreach (GameObject go in gos)
        {
            float distance = Vector3.Distance(go.transform.position, transform.position);

            if (distance <= explosionRadius)
            {
                Transform trans = go.GetComponent<Transform>();
                enemyAnimationController enemyAnimation = go.GetComponent<enemyAnimationController>();
                trans.localScale.Set(trans.localScale.x, trans.localScale.y - 1, trans.localScale.z);

                if (go.GetComponent<archerController>() != null)
                {
                    archerController archer = go.GetComponent<archerController>();

                    archer.health -= explosionDamage;

                    enemyAnimation.explosionDelay();
                }
                else if (go.GetComponent<swordmanController>() != null)
                {
                    swordmanController swordman = go.GetComponent<swordmanController>();

                    swordman.health -= explosionDamage;

                    enemyAnimation.explosionDelay();
                }
                else if (go.GetComponent<mageController>() != null)
                {
                    mageController mage = go.GetComponent<mageController>();

                    mage.health -= explosionDamage;

                    enemyAnimation.explosionDelay();

                }
            }
        }

        Rigidbody rigid = GetComponent<Rigidbody>();
        rigid.useGravity = false;
        Destroy(spawnedImpactEffect, 8);
        Destroy(gameObject, 3);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "ground" && !splashed)
        {
            splash();
        }
    }
}
