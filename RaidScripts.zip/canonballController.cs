﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class canonballController : MonoBehaviour
{
    public GameObject canonball;
    GameObject generatedCanonball;

    towerAttack attack;

    Vector3 canonPlace;
    // Start is called before the first frame update
    void Start()
    {
        attack = GetComponentInParent<towerAttack>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public IEnumerator bombDelay()
    {
        yield return new WaitForSeconds(.7f);

        if (attack.closestEnemy != null)
        {
            Transform enemyTrans = attack.closestEnemy.transform;
            canonPlace = new Vector3(enemyTrans.position.x, enemyTrans.position.y + Random.Range(15, 30), enemyTrans.position.z);

            generatedCanonball = Instantiate(canonball, canonPlace, new Quaternion(0, 0, -180, 0));
        }
    }

    IEnumerator destroyCanonball()
    {
        yield return new WaitForSeconds(5);

        Destroy(generatedCanonball);
    }
}
