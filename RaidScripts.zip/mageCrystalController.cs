﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mageCrystalController : MonoBehaviour
{
    towerAttack attack;
    towerAnimController towerAnim;

    public Animator animator;
    public bool fired;

    Vector3 hitPoint;

    public GameObject lazerSplash;
    GameObject spawnedSplash;

    // Start is called before the first frame update
    void Start()
    {
        attack = GetComponentInParent<towerAttack>();
        towerAnim = GetComponentInParent<towerAnimController>();

        animator = GetComponentInChildren<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if(attack.enemyDist <= attack.ourLookRaidus && attack.closestEnemy != null)
        {
            GameObject crystal = transform.GetChild(0).gameObject;
            crystal.transform.LookAt(attack.closestEnemy.transform);
        }

        if (fired)
        {
            if (attack.closestEnemy != null)
            {
                GameObject closestEnemy = attack.closestEnemy.transform.GetChild(0).gameObject;
                Vector3 closestPos = new Vector3(closestEnemy.transform.position.x, closestEnemy.transform.position.y + 1.5f, closestEnemy.transform.position.z);

                Vector3 stormCloudPos = new Vector3(closestEnemy.transform.position.x + Random.Range(0, 3), closestEnemy.transform.position.y + Random.Range(15, 18), closestEnemy.transform.position.z + Random.Range(0, 3));

                spawnedSplash = Instantiate(lazerSplash, closestPos, new Quaternion(0, 0, 0, 0));

                Destroy(spawnedSplash, 5);

                fired = false;
            }
        }
    }
}
