﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lampPostController : MonoBehaviour
{
    Animator anim;
    collisionCheck collision;

    float turnDelay;
    AudioSource source;
    GameObject lightChild;
    public bool switching;

    public int ourMode;
    // Start is called before the first frame update
    void Awake()
    {
        lightChild = transform.GetChild(0).transform.GetChild(0).gameObject;
        lightChild.SetActive(false);

        source = GetComponent<AudioSource>();
        collision = GetComponent<collisionCheck>();
        anim = GetComponentInChildren<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (collision.colliding)
        {
            anim.SetBool("up", false);
        }
        else
        {
            anim.SetBool("up", true);
        }
    }

    public void changeLight(int newMode)
    {
        switching = true;

        switch (newMode)
        {
            case 0:
                //off 
                turnDelay = Random.Range(0, 5);
                ourMode = 0;
                break;
            case 1:
                //on
                turnDelay = Random.Range(0, 5);
                ourMode = 1;
                break;
        }
        StartCoroutine(lightSwitch(newMode));
    }

    IEnumerator lightSwitch(int mode)
    {
        yield return new WaitForSeconds(turnDelay);
        switching = false;
        realSwitch(mode);
    }

    public void realSwitch(int mode)
    {
        switch (mode)
        {
            case 0:
                lightChild.SetActive(false);
                break;
            case 1:
                lightChild.SetActive(true);
                break;
        }
        source.Play();
    }
}
