﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;


public class sought : MonoBehaviour
{

    public float exposeDist = 2;
    bool found;

    MeshRenderer mesh;
    MeshRenderer[] castleMeshes;

    public Material matNorm;
    public Material matTrans;

    public Material barrackA;

    MeshRenderer mainMesh;
    MeshRenderer doorMeshA;
    MeshRenderer doorMeshB;

    public bool isCastle;
    bool ranGather;

    GameObject closestPath;

    public pathPlaceManager pathManager;
    public placeManager placeManager;
    bool exposed;

    float enemyDist;
    int changedToVisible;
    // Start is called before the first frame update
    void Start()
    {
        changedToVisible = 0;
        exposed = false;
        pathManager = FindObjectOfType<pathPlaceManager>();
        placeManager = FindObjectOfType<placeManager>();

        ranGather = false;
        FindClosestPath();

        if (gameObject.tag == "mound" || gameObject.tag == "tree")
        {
            mesh = GetComponent<MeshRenderer>();
            mesh.material = matTrans;
        }
        else
        {
            if (GetComponentInParent<captureCastleCont>() != null)
            {
                isCastle = true;
            } else if (GetComponentInParent<enemySpawn>() != null)
            {
                mesh = GetComponent<MeshRenderer>();
                mesh.material = matTrans;
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (isCastle && !ranGather)
        {
            if(GetComponentInParent<castleManager>().level == 0)
            {
                ranGather = true;

                mainMesh = GetComponent<MeshRenderer>();

                doorMeshA = transform.GetChild(0).gameObject.GetComponent<MeshRenderer>();
                doorMeshB = transform.GetChild(1).gameObject.GetComponent<MeshRenderer>();

                mainMesh.material = matTrans;

                castleMeshes = new MeshRenderer[3];

                castleMeshes[0] = mainMesh;
                castleMeshes[1] = doorMeshA;
                castleMeshes[2] = doorMeshB;

                foreach(MeshRenderer meshes in castleMeshes)
                {
                    meshes.material = matTrans;
                }
            }
        }

        if (!IsInvoking("FindClosestPath") && !exposed)
        {
            Invoke("FindClosestPath", 1);
        }

        if (closestPath != null)
        {
            enemyDist = Vector3.Distance(closestPath.transform.position, transform.position);
        }
        else if (!exposed)
        {
            FindClosestPath();
        }

        if(enemyDist <= exposeDist)
        {
            exposed = true;
            if (gameObject.tag == "mound" || gameObject.tag == "tree")
            {
                mesh.material = matNorm;
            }
            else
            {
                if (GetComponentInParent<captureCastleCont>() != null && ranGather && changedToVisible != 3)
                {
                    GetComponentInParent<captureCastleCont>().exposed = true;
                    foreach (MeshRenderer meshes in castleMeshes)
                    {
                        meshes.material = barrackA;
                        changedToVisible += 1;
                    }
                } else if (GetComponentInParent<enemySpawn>() != null)
                {
                    mesh.material = matNorm;   
                }
            }
        }
    }

    public void FindClosestPath()
    {
        GameObject[] paths;
        towerAttack[] attacks;
        GameObject[] towers;
        GameObject[] mainCastle;
        GameObject[] seekers;

        paths = GameObject.FindGameObjectsWithTag("path");
        attacks = FindObjectsOfType<towerAttack>();

        towers = new GameObject[attacks.Length];
        for (int i = 0; i < towers.Length; i++)
            towers[i] = attacks[i].gameObject;

        mainCastle = GameObject.FindGameObjectsWithTag("mainCastle");

        seekers = paths.Concat(towers).Concat(mainCastle).ToArray();

        closestPath = null;
        float distance = Mathf.Infinity;
        Vector3 position = transform.position;

        foreach (GameObject go in seekers)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance && distance != 0)
            {
                closestPath = go;
                distance = curDistance;
            }
        }
    }

}
