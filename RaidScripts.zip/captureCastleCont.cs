﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class captureCastleCont : MonoBehaviour
{
    public bool captured;
    public bool connected;
    public bool exposed;

    bool reaped;
    public int timesCaptured;

    GameObject mainCastle;
    moneyManager money;

    public GameObject captureConfetti;

    public GameObject destructionExplosion;
    public GameObject newCon;
    // Start is called before the first frame update
    void Start()
    {
        timesCaptured = 1;

        mainCastle = GameObject.FindGameObjectWithTag("mainCastle");
        money = mainCastle.GetComponent<moneyManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if(captured)
        {
            if (!reaped)
            {
                reaped = true;
                Vector3 confettiPos = new Vector3(transform.position.x, transform.position.y + 6, transform.position.z);
                GameObject ourConfet = Instantiate(captureConfetti, confettiPos, new Quaternion(0, 0, 0, 0));
                Destroy(ourConfet, 10);
                FindObjectOfType<audioManager>().play("partyPopper");
            }
        }
    }

    public void destroyed(GameObject newCon)
    {
        GameObject explosion = Instantiate(destructionExplosion, transform.position, transform.rotation);
        explosion.transform.parent = null;
        tag = "mound";
    }
}
