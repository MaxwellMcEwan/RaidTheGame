﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class towerSelector : MonoBehaviour
{
    public placeManager placeManager;

    public int selectedTower;

    public Transform towerOpen;

    public GameObject currentWall;

    GameObject strWall;
    GameObject strTower;

    public int wallForm;
    public bool wallActive;

    KeyCode placingArchKey = KeyCode.Alpha1;
    KeyCode placingCanKey = KeyCode.Alpha2;
    KeyCode placingMageKey = KeyCode.Alpha3;
    KeyCode placingWallKey = KeyCode.Alpha4;

    // Start is called before the first frame update
    private void Awake()
    {
        gameObject.SetActive(false);
    }

    void Start()
    {
        selectedTower = placeManager.selectedTower;

        selectTower();
    }

    // Update is called once per frame
    void Update()
    {
        if (placeManager.placing)
        {
            int previousSelectedTower = selectedTower;

            if (Input.GetKeyUp(placingArchKey))
            {
                selectedTower = 0;
            } else if (Input.GetKeyUp(placingCanKey))
            {
                selectedTower = 1;
            } else if (Input.GetKeyUp(placingMageKey))
            {
                selectedTower = 2;
            } else if (Input.GetKeyUp(placingWallKey))
            {
                selectedTower = 3;
            }

            if (Input.GetAxis("Mouse ScrollWheel") > 0)
            {
                if (selectedTower >= 4 - 1)
                    selectedTower = 0;
                else
                    selectedTower++;
            }
            if (Input.GetAxis("Mouse ScrollWheel") < 0)
            {
                if (selectedTower <= 0)
                    selectedTower = 4 - 1;
                else
                    selectedTower--;
            }


            if (previousSelectedTower != selectedTower)
            {
                selectTower();
            }
        }

        if (wallActive)
        {
            MeshRenderer wallRend = strWall.GetComponent<MeshRenderer>();
            MeshRenderer towerRend = strTower.GetComponent<MeshRenderer>();
            switch (wallForm)
            {
                case 0:
                    wallRend.enabled = true;
                    towerRend.enabled = false;
                    break;
                case 1:
                    wallRend.enabled = false;
                    towerRend.enabled = true;
                    break;
            }
        }

    }

    void selectTower()
    {
        int i = 0;

        foreach (Transform tower in transform)
        {
            if (i == selectedTower)
            {
                towerOpen = tower.transform;

                if(tower.name == "wallEmpty")
                {
                    wallActive = true;
                    strWall = tower.GetChild(0).gameObject;
                    strTower = tower.GetChild(1).gameObject;

                    MeshRenderer wallRend = strWall.GetComponent<MeshRenderer>();
                    MeshRenderer towerRend = strTower.GetComponent<MeshRenderer>();

                    wallRend.enabled = true;
                    towerRend.enabled = false;
                }
                else
                {
                    MeshRenderer meshRend = tower.GetComponent<MeshRenderer>();
                    MeshRenderer childMeshRend = tower.GetComponentInChildren<MeshRenderer>();

                    meshRend.enabled = true;
                }
            }
            else
            {
                if (tower.name == "wallEmpty")
                {
                    wallActive = false;
                    strWall = tower.GetChild(0).gameObject;
                    strTower = tower.GetChild(1).gameObject;

                    MeshRenderer wallRend = strWall.GetComponent<MeshRenderer>();
                    MeshRenderer towerRend = strTower.GetComponent<MeshRenderer>();

                    wallRend.enabled = false;
                    towerRend.enabled = false;
                }
                else
                {
                    MeshRenderer meshRend = tower.GetComponent<MeshRenderer>();
                    MeshRenderer childMeshRend = tower.GetComponentInChildren<MeshRenderer>();

                    meshRend.enabled = false;
                }

            }

            i++;
        }

        placeManager.selectedTower = selectedTower;
    }
}
