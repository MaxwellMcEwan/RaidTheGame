﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class footStepController : MonoBehaviour
{
    AudioSource source;
    Animator anim;

    bool canStep;
    bool foundType;

    int ourType;
    // Start is called before the first frame update
    void Start()
    {
        source = GetComponent<AudioSource>();
        anim = GetComponent<Animator>();

        canStep = true;

        findOurType();
    }

    // Update is called once per frame
    void Update()
    {
        if (foundType)
        {
            switch (ourType)
            {
                case 0:
                    if (!anim.GetBool("fighting") && !anim.GetBool("died") && canStep)
                    {
                        StartCoroutine(footStepTimer());
                        canStep = false;
                    }
                    break;

                case 1:
                    if (!anim.GetBool("firing") && !anim.GetBool("died") && canStep)
                    {
                        StartCoroutine(footStepTimer());
                        canStep = false;
                    }
                    break;

                case 2:
                    if (!anim.GetBool("casting") && !anim.GetBool("died") && canStep)
                    {
                        StartCoroutine(footStepTimer());
                        canStep = false;
                    }
                    break;
            }
        }
    }

    IEnumerator footStepTimer()
    {
        source.Play();

        yield return new WaitForSeconds(anim.GetCurrentAnimatorClipInfo(0).Length);

        canStep = true;
    }

    void findOurType()
    {
        if (GetComponentInParent<swordmanController>() != null)
            ourType = 0;
        else if (GetComponentInParent<archerController>() != null)
            ourType = 1;
        else if (GetComponentInParent<mageController>() != null)
            ourType = 2;

        foundType = true;
    }

}
