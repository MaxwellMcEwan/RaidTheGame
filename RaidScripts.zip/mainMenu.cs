﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenu : MonoBehaviour
{
    public GameObject openScene0;
    public GameObject openScene1;
    public GameObject openScene2;

    bool setNewScene;
    public void QuitGame()
    {
        Application.Quit();
    }

    private void Awake()
    {
        if(PlayerPrefs.GetInt("beatLevels") <= 5)
        {
            openScene0.SetActive(true);
            openScene1.SetActive(false);
            openScene2.SetActive(false);
        }
        else if (PlayerPrefs.GetInt("beatLevels") > 5 && PlayerPrefs.GetInt("beatLevels") < 13)
        {
            openScene0.SetActive(false);
            openScene1.SetActive(true);
            openScene2.SetActive(false);
        }
        else if(PlayerPrefs.GetInt("beatLevels") >= 13)
        {
            openScene0.SetActive(false);
            openScene1.SetActive(false);
            openScene2.SetActive(true);
        }
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
