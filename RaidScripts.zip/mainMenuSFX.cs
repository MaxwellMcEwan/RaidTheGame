﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mainMenuSFX : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void xButtonTriggered()
    {
        FindObjectOfType<audioManager>().play("uiXButtonClick");
    }

    public void directoryButtonTriggered()
    {
        FindObjectOfType<audioManager>().play("uiDirectButtonClick");
    }
}
