﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mageTower : MonoBehaviour
{
    [HideInInspector] public int level;
    [HideInInspector] public bool construction;

    public GameObject mage0Con;
    public GameObject mage0;

    public GameObject mage1Con;
    public GameObject mage1;

    public GameObject mage2Con;
    public GameObject mage2;

    public GameObject mage3ConA;
    public GameObject mage3A;

    public GameObject mage3ConB;
    public GameObject mage3B;

    GameObject currentTow;
    GameObject currentCon;

    [HideInInspector]public int maxhealth;
    [HideInInspector]public int health;

    [HideInInspector]public int damage;
    [HideInInspector]public float cooldown;

    [HideInInspector]public float lookRadius;

    public GameObject buildSmoke;
    GameObject destroySmoke;
    GameObject smoke;
    public GameObject destroyExplosion;

    public GameObject tilledGround;

    [HideInInspector] public bool choseAOrB;
    [HideInInspector] public bool recentlyHit;

    public Material matNorm;
    public Material matSelected;
    MeshRenderer childMesh;
    MeshRenderer grandChildMesh;
    // Start is called before the first frame update
    void Start()
    {
        maxhealth = 15;
        health = maxhealth; 
    }

    // Update is called once per frame
    void Update()
    {
        if (health <= 0)
            broken();

        if (construction)
            return;
    }

    public void onSelect()
    {
        childMesh.material = matSelected;
        if (grandChildMesh != null && !construction)
            grandChildMesh.material = matSelected;
    }

    public void onNorm()
    {
        childMesh.material = matNorm;
        if (grandChildMesh != null && !construction)
            grandChildMesh.material = matNorm;
    }

    void levelController()
    {
        childMesh = currentTow.GetComponent<MeshRenderer>();
        grandChildMesh = currentTow.transform.GetChild(0).GetComponent<MeshRenderer>();

        switch (level)
        {
            case 0:

                maxhealth = 15;
                damage = 1;
                cooldown = 1f;
                lookRadius = 25;

                break;

            case 1:

                maxhealth = 20;
                damage = 1;
                cooldown = .7f;
                lookRadius = 25;

                break;

            case 2:

                maxhealth = 30;
                damage = 2;
                cooldown = .5f;
                lookRadius = 30;

                break;

            case 3:

                maxhealth = 40;
                damage = 4;
                cooldown = .5f;
                lookRadius = 35;

                break;

            case 4:

                maxhealth = 40;
                damage = 2;
                cooldown = .2f;
                lookRadius = 35;

                break;
        }
    }

    void broken()
    {
        FindObjectOfType<audioManager>().play("woodBreak");
        Instantiate(destroyExplosion, transform.position, transform.rotation, null);
        Destroy(gameObject);
        return;
    }

    public IEnumerator upgrade0()
    {
        GameObject ground = Instantiate(tilledGround, new Vector3(transform.position.x, transform.position.y + .38f, transform.position.z), transform.rotation);
        smoke = Instantiate(buildSmoke, transform);

        GameObject con0 = Instantiate(mage0Con, transform);

        construction = true;

        childMesh = con0.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(5);

        Destroy(con0);
        destroySmoke = smoke;
        StartCoroutine(smokeDestroyDelay());

        GameObject tow0 = Instantiate(mage0, transform);

        currentTow = tow0;

        construction = false;

        level = 0;
        levelController();
        health = 15;
    }

    public IEnumerator upgrade1()
    {
        construction = true;
        Destroy(currentTow);

        GameObject con1 = Instantiate(mage1Con, transform);

        childMesh = con1.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(10);

        construction = false;
        Destroy(con1);

        GameObject tow1 = Instantiate(mage1, transform);

        currentTow = tow1;

        level = 1;
        health = 20;
        levelController();
    }

    public IEnumerator upgrade2()
    {
        construction = true;
        Destroy(currentTow);

        GameObject con2 = Instantiate(mage2Con, transform);

        childMesh = con2.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(15);

        construction = false;
        Destroy(con2);

        GameObject tow2 = Instantiate(mage2, transform);

        currentTow = tow2;

        level = 2;
        health = 30;
        levelController();
    }

    public IEnumerator upgrade3A()
    {
        choseAOrB = true;
        construction = true;
        Destroy(currentTow);

        GameObject con3A = Instantiate(mage3ConA, transform);

        childMesh = con3A.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(25);

        construction = false;
        Destroy(con3A);

        GameObject tow3A = Instantiate(mage3A, transform);

        currentTow = tow3A;

        level = 3;
        levelController();
        health = 40;
    }

    public IEnumerator upgrade3B()
    {
        choseAOrB = true;
        construction = true;
        Destroy(currentTow);

        GameObject con3B = Instantiate(mage3ConB, transform);

        childMesh = con3B.GetComponent<MeshRenderer>();
        yield return new WaitForSeconds(25);

        construction = false;
        Destroy(con3B);

        GameObject tow3B = Instantiate(mage3B, transform);

        currentTow = tow3B;

        level = 4;
        levelController();
        health = 40;
    }

    IEnumerator smokeDestroyDelay()
    {
        yield return new WaitForSeconds(1.3f);

        Destroy(destroySmoke);
    }

    public IEnumerator recentlyHitTimer()
    {
        recentlyHit = true;

        yield return new WaitForSeconds(5);

        recentlyHit = false;
    }
    public IEnumerator repair()
    {
        Destroy(currentTow);
        construction = true;
        smoke = Instantiate(buildSmoke, transform);

        switch (level)
        {
            case 0:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(50);

                GameObject con0 = Instantiate(mage0Con, transform);
                currentCon = con0;
                break;

            case 1:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(100);

                GameObject con1 = Instantiate(mage1Con, transform);
                currentCon = con1;
                break;

            case 2:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(150);

                GameObject con2 = Instantiate(mage2Con, transform);
                currentCon = con2;
                break;

            case 3:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(200);

                GameObject con3A = Instantiate(mage3ConA, transform);
                currentCon = con3A;
                break;

            case 4:

                smoke.GetComponent<ParticleSystem>().main.maxParticles.Equals(200);

                GameObject con3B = Instantiate(mage3ConB, transform);
                currentCon = con3B;
                break;
        }

        yield return new WaitForSeconds((maxhealth - health) / 2);

        Destroy(currentCon);
        Destroy(smoke);

        switch (level)
        {
            case 0:
                GameObject tow0 = Instantiate(mage0, transform);

                currentTow = tow0;
                break;

            case 1:
                GameObject tow1 = Instantiate(mage1);

                currentTow = tow1;
                break;

            case 2:
                GameObject tow2 = Instantiate(mage2, transform);

                currentTow = tow2;
                break;

            case 3:
                GameObject tow3A = Instantiate(mage3A, transform);

                currentTow = tow3A;
                break;

            case 4:

                GameObject tow3B = Instantiate(mage3B, transform);

                currentTow = tow3B;
                break;
        }

        construction = false;
        health = maxhealth;
    }
}
