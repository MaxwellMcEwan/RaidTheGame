﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemySpawn : MonoBehaviour
{
    public bool activated;
    public bool triggered;

    public GameObject soldier;
    public GameObject archer;
    public GameObject mage;

    enemyManager manager;

    int spawnType;
    int unitType;
    public float troopsToSpawn;
    int troopsSpawned;
    int spawningRound;

    public GameObject ourCastle;

    float coolTime;
    public float miniCoolTime;
    float spawnDuration;

    float miniCoolDEF = .5f;

    public bool cooling;
    public bool miniCooling;
    public bool spawnTiming;
    public bool spawnFertile;

    lightManager lightMan;
    bool night;
    bool finalActivated;

    bool activatedChild;
    // Start is called before the first frame update
    void Start()
    {
        transform.GetChild(0).gameObject.SetActive(false);

        lightMan = FindObjectOfType<lightManager>();

        spawnFertile = true;
        miniCoolTime = miniCoolDEF;
        coolTime = 30;
        spawnDuration = 2;

        manager = FindObjectOfType<enemyManager>();

        if (ourCastle == GameObject.FindGameObjectWithTag("mainCastle"))
        {
            triggered = true;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!triggered)
        {
            if (ourCastle.GetComponent<captureCastleCont>().captured)
            {
                triggered = true;
            }
        }
        else if(!activatedChild)
        {
            transform.GetChild(0).gameObject.SetActive(true);
            activatedChild = true;
        }

        if (activated)
        {
            spawnableTroops();
            spawnMind();

            if (!activatedChild)
            {
                transform.GetChild(0).gameObject.SetActive(true);
                activatedChild = true;
            }

        }
    }

    void spawnMind()
    {
        if (!cooling && spawnFertile)
        {
            if (finalActivated || lightMan.night)
            {
                if (troopsSpawned < troopsToSpawn)
                {
                    troopsSpawned += 1;
                    switch (spawnType)
                    {
                        case 0:
                            spawnSoldier();
                            break;
                        case 1:

                            unitType += 1;
                            if (unitType > 1)
                                unitType = 0;

                            switch (unitType)
                            {
                                case 0:
                                    spawnSoldier();

                                    break;
                                case 1:
                                    spawnArcher();

                                    break;
                            }

                            break;
                        case 2:

                            unitType += 1;
                            if (unitType > 2)
                                unitType = 0;

                            switch (unitType)
                            {
                                case 0:
                                    spawnSoldier();

                                    break;
                                case 1:
                                    spawnArcher();

                                    break;

                                case 3:
                                    spawnMage();
                                    break;
                            }

                            break;
                    }
                }

                if (!spawnTiming)
                    StartCoroutine(spawnTimer());
            }
        }
    }

    IEnumerator miniSpawnCool()
    {
        miniCooling = true;
        yield return new WaitForSeconds(miniCoolTime);
        miniCooling = false;
    }

    IEnumerator spawnCoolestCooler()
    {
        cooling = true;
        spawnTiming = false;
        yield return new WaitForSeconds(coolTime);
        cooling = false;
    }

    IEnumerator spawnTimer()
    {
        spawnTiming = true;
        spawningRound += 1;
        troopsToSpawn += 1f;
        yield return new WaitForSeconds(spawnDuration);
        troopsSpawned = 0;
        StartCoroutine(spawnCoolestCooler());
    }

    void spawnableTroops()
    {
        switch (spawningRound)
        {
            case 0:
                spawnType = 0;
                break;
            case 3:
                spawnType = 1;
                break;
            case 7:
                spawnType = 2;
                break;
        }
    }

    void spawnSoldier()
    {
        Instantiate(soldier, transform.position, transform.rotation);
    }

    void spawnArcher()
    {
        Instantiate(archer, transform.position, transform.rotation);
    }

    void spawnMage()
    {
        Instantiate(mage, transform.position, transform.rotation);
    }

    public IEnumerator hyperCool()
    {
        finalActivated = true;
        yield return new WaitForSeconds(spawnDuration);
        miniCoolTime = miniCoolDEF;
        spawnFertile = false;
    }
}
