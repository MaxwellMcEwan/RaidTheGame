﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moneyCollector : MonoBehaviour
{
    GameObject mainCastle;

    startup start;
    moneyManager money;
    castleManager castle;
    captureCastleCont captureCastle;

    bool collectingMoney;
    public int coinGained = 2;

    // Start is called before the first frame update
    void Start()
    {
        mainCastle = GameObject.FindGameObjectWithTag("mainCastle");

        start = mainCastle.GetComponent<startup>();
        money = mainCastle.GetComponent<moneyManager>();
        castle = GetComponent<castleManager>();
        captureCastle = GetComponent<captureCastleCont>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!collectingMoney && start.setup && captureCastle.captured)
            StartCoroutine(moneyCollect());
    }

    IEnumerator moneyCollect()
    {
        collectingMoney = true;

        yield return new WaitForSeconds(money.coinCoolTime * 2);

        money.coin += coinGained;

        collectingMoney = false;
    }
}
