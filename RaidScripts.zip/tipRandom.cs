﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class tipRandom : MonoBehaviour
{
    public Text tipText;
    string[] tipList;

    string waterTip = "Drink more water!";
    string commitTip = "Commit yourself to something!";
    string gratefulTip = "What is something you're grateful for?";
    string grudgeTip = "Don't hold grudges, it will ware you out";
    string takeCareTip = "Helping others is good for your mental health!";
    string bodyHealthTip = "Try to exercise at least 30 minutes a day";
    string happyTip = "Do the things that make you happy!";
    string meaningTip = "Look for meaning, if you can't see any, make some";

    private void Awake()
    {
        tipList = new string[8];

        tipList[0] = waterTip;
        tipList[1] = commitTip;
        tipList[2] = gratefulTip;
        tipList[3] = grudgeTip;
        tipList[4] = takeCareTip;
        tipList[5] = bodyHealthTip;
        tipList[6] = happyTip;
        tipList[7] = meaningTip;

        int randomTip = Random.Range(0, 8);

        tipText.text = "Tip of the day: " + tipList[randomTip];
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
