﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pathArrowController : MonoBehaviour
{
    public bool avaliable;

    public bool touchingPath;
    public GameObject pathColl;
    public MeshRenderer mesh;
    public bool immoveable;
    // Start is called before the first frame update
    void Start()
    {
        immoveable = false;
        avaliable = true;

        mesh = GetComponent<MeshRenderer>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag != "tree" && other.tag != "ground")
        {
            if (other.tag == "path")
            {
                touchingPath = true;
                mesh.enabled = false;

                pathColl = other.gameObject;
            }
            else
            {
                if (other.tag != "selector")
                {
                    mesh.enabled = false;
                    immoveable = true;
                }
                else
                {
                    if(other.GetComponent<tradeRouteController>() != null)
                    {
                        immoveable = true;
                    }
                }
            }
        }
    }
}
