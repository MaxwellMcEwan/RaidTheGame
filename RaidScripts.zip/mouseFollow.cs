﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mouseFollow : MonoBehaviour
{
    Camera cam;
    Vector3 target;

    public float smoothSpeed = 0.5f;

    public bool isFollowing;
    int groundMask;
    private Grid gGrid;

    float amountOver0;

    private void Awake()
    {
        groundMask = LayerMask.GetMask("Ground");
    }
    // Start is called before the first frame update
    void Start()
    {
        gGrid = Grid.FindObjectOfType<Grid>();

        groundMask = 1 << 9;

        isFollowing = true;

        cam = Camera.main;

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (isFollowing)
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, Mathf.Infinity, groundMask))
            {
                target = new Vector3(hit.point.x, 0, hit.point.z);
                Vector3Int cp = gGrid.LocalToCell(target);

                transform.position = gGrid.GetCellCenterLocal(cp);
            }
        }
    }
}
