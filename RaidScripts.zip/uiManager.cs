﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class uiManager : MonoBehaviour
{
    public Text coinText;

    public GameObject mainCastle;
    public GameObject castlePlacement;
    public GameObject gameManager;
    public GameObject towerUpgrade;

    moneyManager money;
    placeManager place;
    startup start;
    pathPlaceManager pathPlace;
    enemyManager enemyMan;
    towerUpgrader upgrader;

    public bool raidAnimated;
    bool invalidDelaying;

    Animation coinAnim;
    // Start is called before the first frame update
    void Start()
    {
        money = mainCastle.GetComponent<moneyManager>();
        place = mainCastle.GetComponent<placeManager>();
        start = mainCastle.GetComponent<startup>();
        pathPlace = castlePlacement.GetComponent<pathPlaceManager>();
        enemyMan = gameManager.GetComponent<enemyManager>();
        upgrader = towerUpgrade.GetComponent<towerUpgrader>();

        coinAnim = coinText.gameObject.GetComponent<Animation>();
    }

    // Update is called once per frame
    void Update()
    {
        coinText.text = "" + money.coin;

        if(place.tooPoor || !upgrader.fundingSecured)
        {
            place.tooPoor = false;
            upgrader.fundingSecured = true;

            if (!coinAnim.isPlaying)
                coinAnim.Play();
            else
            {
                coinAnim.Rewind();
                coinAnim.Play();
            }

            FindObjectOfType<audioManager>().play("ranCoin");
        }
    }
}
