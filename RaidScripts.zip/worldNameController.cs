﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class worldNameController : MonoBehaviour
{
    public string WorldName;
    Text worldText;

    // Start is called before the first frame update
    void Awake()
    {
        worldText = GetComponent<Text>();
        worldText.text = WorldName;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
