﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class optionsMenu : MonoBehaviour
{
    public AudioMixer mixer;

    public Dropdown resoloutionDropdown;
    Resolution[] resoloutions;

    static float masterVol;
    static float musicVol;
    static float sfxVol;

    Slider masterVolSL;
    Slider musicVolSL;
    Slider SFXVolSL;

    public GameObject continueButton;

    public Text kingdomText;

    void Start()
    {
        Screen.fullScreenMode = FullScreenMode.MaximizedWindow;
    }

    public void setQuality(int qualityIndex)
    {
        QualitySettings.SetQualityLevel(qualityIndex);
    }

    public void setVolume(float volume)
    {
        mixer.SetFloat("volume", volume);

        masterVol = volume;
    }

    public void setSfxVolume(float sfxVolume)
    {
        mixer.SetFloat("sfxVolume", sfxVolume);

        sfxVol = sfxVolume;
    }

    public void setMusicVolume(float musicVolume)
    {
        mixer.SetFloat("musicVolume", musicVolume);

        musicVol = musicVolume;
    }


    public void updateVolumeSliders()
    {
        Slider[] sliders = FindObjectsOfType<Slider>();

        foreach(Slider SL in sliders)
        {
            if (SL.name == "masterVolume")
                masterVolSL = SL;
            else if (SL.name == "musicVolume")
                musicVolSL = SL;
            else if (SL.name == "SFXVolume")
                SFXVolSL = SL;
        }

        masterVolSL.value = masterVol;
        musicVolSL.value = musicVol;
        SFXVolSL.value = sfxVol;
    }

    public void callZuesChange()
    {
        FindObjectOfType<kingdomTracker>().changeName();
    }

    public void updateZues(InputField input)
    {
        FindObjectOfType<kingdomTracker>().upDateKingdomName(input);
        FindObjectOfType<kingdomTracker>().updateText(kingdomText);
    }

    public void finalZues(InputField input)
    {
        FindObjectOfType<kingdomTracker>().enteredName(input);
        FindObjectOfType<kingdomTracker>().updateText(kingdomText);

        FindObjectOfType<levelLoader>().updateTag();
        FindObjectOfType<audioManager>().play("elevator");
    }

    public void setClanEverred()
    {
        PlayerPrefs.SetInt("tribe", 0);
    }
    public void setClanWolff()
    {
        PlayerPrefs.SetInt("tribe", 1);
    }
    public void setClanRagnar()
    {
        PlayerPrefs.SetInt("tribe", 2);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
