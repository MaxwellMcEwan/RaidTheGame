﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class archerHolder : MonoBehaviour
{
    archerTower archer;
    towerAttack tower;
    public Animator troopAnim;

    Transform holder0;
    Transform holder1;
    Transform holder2;
    Transform holder3;
    Transform holder4;
    Transform holder5;

    public GameObject currentArcher;
    public GameObject currentArcher1;
    public GameObject archerTroopPRE;

    public bool archersAdded;
    public AudioSource sourceArcher0;
    public AudioSource sourceArcher1;

    Animator troop0Animator;
    Animator troop1Animator;

    bool animatedPop;
    // Start is called before the first frame update
    void Awake()
    {
        troopAnim = GetComponentInChildren<Animator>();

        archersAdded = false;
        archer = GetComponentInParent<archerTower>();
        tower = GetComponentInParent<towerAttack>();
    }

    // Update is called once per frame
    void Update()
    {
        if (archer.health > 0)
        {
            switch (archer.level)
            {
                case 0:

                    if (!archersAdded)
                    {
                        archersAdded = true;
                        holder0 = gameObject.transform.GetChild(0).transform;
                        currentArcher = Instantiate(archerTroopPRE, holder0);

                        sourceArcher0 = holder0.GetChild(0).GetComponent<AudioSource>();
                    }
                    else
                    {
                        if (tower.enemyDist <= tower.ourLookRaidus && tower.closestEnemy != null)
                        {
                            Transform targetTrans = tower.closestEnemy.transform;
                            Vector3 targetPoint = new Vector3(targetTrans.position.x, targetTrans.position.y, targetTrans.position.z) - currentArcher.transform.position;

                            Quaternion targetRotation = Quaternion.LookRotation(-targetPoint, Vector3.up);
                            currentArcher.transform.rotation = Quaternion.Slerp(currentArcher.transform.rotation, targetRotation, Time.deltaTime * 2.0f);
                        }
                    }

                    break;

                case 1:

                    if (!archersAdded)
                    {
                        archersAdded = true;
                        holder1 = gameObject.transform.GetChild(0).transform;
                        currentArcher = Instantiate(archerTroopPRE, holder1);

                        sourceArcher0 = holder1.GetChild(0).GetComponent<AudioSource>();
                    }
                    else
                    {
                        if (tower.enemyDist <= tower.ourLookRaidus && tower.closestEnemy != null)
                        {
                            Transform targetTrans = tower.closestEnemy.transform;
                            Vector3 targetPoint = new Vector3(targetTrans.position.x, targetTrans.position.y, targetTrans.position.z) - currentArcher.transform.position;

                            Quaternion targetRotation = Quaternion.LookRotation(-targetPoint, Vector3.up);
                            currentArcher.transform.rotation = Quaternion.Slerp(currentArcher.transform.rotation, targetRotation, Time.deltaTime * 2.0f);
                        }
                    }

                    break;

                case 2:

                    if (!archersAdded)
                    {
                        archersAdded = true;
                        holder2 = gameObject.transform.GetChild(0).transform;
                        currentArcher = Instantiate(archerTroopPRE, holder2);

                        sourceArcher0 = holder2.GetChild(0).GetComponent<AudioSource>();
                    }
                    else
                    {
                        if (tower.enemyDist <= tower.ourLookRaidus && tower.closestEnemy != null)
                        {
                            Transform targetTrans = tower.closestEnemy.transform;
                            Vector3 targetPoint = new Vector3(targetTrans.position.x, targetTrans.position.y, targetTrans.position.z) - currentArcher.transform.position;

                            Quaternion targetRotation = Quaternion.LookRotation(-targetPoint, Vector3.up);
                            currentArcher.transform.rotation = Quaternion.Slerp(currentArcher.transform.rotation, targetRotation, Time.deltaTime * 2.0f);
                        }
                    }

                    break;

                case 3:

                    if (!archersAdded)
                    {
                        archersAdded = true;
                        holder3 = gameObject.transform.GetChild(0).transform;
                        currentArcher = Instantiate(archerTroopPRE, holder3);

                        sourceArcher0 = holder3.GetChild(0).GetComponent<AudioSource>();
                    }
                    else
                    {
                        if (tower.enemyDist <= tower.ourLookRaidus && tower.closestEnemy != null)
                        {
                            Transform targetTrans = tower.closestEnemy.transform;
                            Vector3 targetPoint = new Vector3(targetTrans.position.x, targetTrans.position.y, targetTrans.position.z) - currentArcher.transform.position;

                            Quaternion targetRotation = Quaternion.LookRotation(-targetPoint, Vector3.up);
                            currentArcher.transform.rotation = Quaternion.Slerp(currentArcher.transform.rotation, targetRotation, Time.deltaTime * 2.0f);
                        }
                    }

                    break;

                case 4:
                    if (!archersAdded)
                    {
                        archersAdded = true;

                        holder4 = gameObject.transform.GetChild(0).transform;
                        holder5 = gameObject.transform.GetChild(1).transform;

                        currentArcher = Instantiate(archerTroopPRE, holder4);
                        currentArcher1 = Instantiate(archerTroopPRE, holder5);

                        sourceArcher0 = holder4.GetChild(0).GetComponent<AudioSource>();
                        sourceArcher1 = holder5.GetChild(0).GetComponent<AudioSource>();
                    }
                    else
                    {
                        if (tower.enemyDist <= tower.ourLookRaidus && tower.closestEnemy != null)
                        {
                            Transform targetTrans = tower.closestEnemy.transform;
                            Vector3 targetPoint = new Vector3(targetTrans.position.x, targetTrans.position.y, targetTrans.position.z) - currentArcher.transform.position;

                            Quaternion targetRotation = Quaternion.LookRotation(-targetPoint, Vector3.up);
                            currentArcher.transform.rotation = Quaternion.Slerp(currentArcher.transform.rotation, targetRotation, Time.deltaTime * 2.0f);
                        }
                    }
                    break;
            }
        }
    }
}
