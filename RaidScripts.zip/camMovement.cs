﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camMovement : MonoBehaviour
{
    public placeManager placeManager;
    public pathPlaceManager pathPlace;

    public float panSpeed = 20;
    public float panBorderThickness = 10f;

    public Vector2 panLimit;


    public float scrollSpeed = 30;
    float minY = 15;
    float maxY = 70;

    float scroll;

    int cameraMode;

    Vector3 rtsPos;
    Vector3 rtsSETRot;

    Vector3 birdPos;
    Vector3 birdRot;

    float mouseSensitivity = 100f;
    float xRotation = 0;

    GameObject birdDummy;
    CharacterController birdController;

    float birdSpeed = 12;

    KeyCode switchCamKey = KeyCode.Z;
    private void Awake()
    {
        GameObject maincastle = GameObject.FindGameObjectWithTag("mainCastle");

        Vector3 firstPos = maincastle.transform.position;
        Vector3 posOffset = new Vector3(0, transform.position.y, -40);

        rtsPos = firstPos + posOffset;
    }

    // Start is called before the first frame update
    void Start()
    {
        rtsSETRot = new Vector3(45, 0, 0);
        birdDummy = transform.parent.gameObject;
        birdController = birdDummy.GetComponent<CharacterController>();
        cameraMode = 0;

        Cursor.lockState = CursorLockMode.Confined;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyUp(switchCamKey))
        {
            cameraMode += 1;
            FindObjectOfType<audioManager>().play("cameraShutter");
        }
        if (cameraMode == 2)
        {
            cameraMode = 0;
        }

        Vector3 pos = transform.position;

        switch (cameraMode)
        {
            case 0:
                Cursor.lockState = CursorLockMode.Confined;
                Cursor.visible = true;

                if (Input.GetKey("w") || Input.mousePosition.y >= Screen.height - panBorderThickness)
                {
                    rtsPos.z += panSpeed * Time.deltaTime;
                }
                if (Input.GetKey("s") || Input.mousePosition.y <= panBorderThickness)
                {
                    rtsPos.z -= panSpeed * Time.deltaTime;
                }
                if (Input.GetKey("d") || Input.mousePosition.x >= Screen.width - panBorderThickness)
                {
                    rtsPos.x += panSpeed * Time.deltaTime;
                }
                if (Input.GetKey("a") || Input.mousePosition.x <= panBorderThickness)
                {
                    rtsPos.x -= panSpeed * Time.deltaTime;
                }

                if (!placeManager.placing)
                {
                    scroll = Input.GetAxis("Mouse ScrollWheel");
                }

                if (!pathPlace.placingCast)
                {
                    if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.DownArrow))
                    {
                        if (Input.GetKey(KeyCode.UpArrow))
                        {
                            scroll = .1f;
                        }
                        else
                        {
                            scroll = -.1f;
                        }
                    }
                    if (Input.GetKeyUp(KeyCode.UpArrow) || Input.GetKeyUp(KeyCode.DownArrow))
                    {
                        scroll = 0;
                    }
                }
                else
                {
                    if (Input.GetKeyUp(KeyCode.E))
                    {
                        GameObject[] paths = GameObject.FindGameObjectsWithTag("path");

                        foreach (GameObject thePath in paths)
                        {
                            if (thePath.transform.name == "firstCell")
                            {
                                Vector3 firstPos = thePath.transform.position;
                                Vector3 posOffset = new Vector3(0, transform.position.y, -40);

                                rtsPos = firstPos + posOffset;
                            }
                        }
                    }
                }


                if (Input.GetKey(KeyCode.LeftShift))
                {
                    panSpeed = 30;
                }
                else
                {
                    panSpeed = 20;
                }


                rtsPos.y -= scroll * scrollSpeed * Time.deltaTime * 100;

                rtsPos.x = Mathf.Clamp(rtsPos.x, -panLimit.x, panLimit.x);
                rtsPos.y = Mathf.Clamp(rtsPos.y, minY, maxY);
                rtsPos.z = Mathf.Clamp(rtsPos.z, -panLimit.y, panLimit.y);

                transform.position = rtsPos;
                transform.rotation = Quaternion.Euler(rtsSETRot);
                break;

            case 1:
                pathPlace.placingCast = false;
                placeManager.placing = false;

                birdPos = birdDummy.transform.position;
                birdRot = birdDummy.transform.rotation.eulerAngles;

                Cursor.lockState = CursorLockMode.Confined;
                Cursor.visible = true;

                float x = Input.GetAxis("Horizontal");
                float z = Input.GetAxis("Vertical");

                Vector3 move = transform.right * x + birdDummy.transform.forward * z;

                birdController.Move(move * birdSpeed * Time.deltaTime);

                if (Input.GetKey(KeyCode.LeftShift))
                {
                    birdSpeed = 30;
                }
                else
                {
                    birdSpeed = 20;
                }

                if (Input.GetKey(KeyCode.Space) && birdPos.y <= 40)
                {
                    birdDummy.transform.Translate(0, 15 * Time.deltaTime, 0);
                }
                if(Input.GetKey(KeyCode.LeftControl) && birdPos.y >= 8)
                {
                    birdDummy.transform.Translate(0, -15 * Time.deltaTime, 0);
                }

                if (Input.GetMouseButton(1))
                {
                    Cursor.lockState = CursorLockMode.Locked;
                    Cursor.visible = false;

                    float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
                    float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

                    xRotation -= mouseY;
                    xRotation = Mathf.Clamp(xRotation, -70f, 70f);

                    birdDummy.transform.Rotate(Vector3.up, mouseX);
                }
                transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);

                transform.position = birdDummy.transform.position;
                break;
        }
    }
}
