﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Linq;

public class gameManager : MonoBehaviour
{
    [HideInInspector] public bool gameLost;
    [HideInInspector] public bool gameWon;
    [HideInInspector] public bool canFinal;

    bool animatedWin;
    bool animatedLoss;
    bool animatedRoundStart;

    public GameObject winAnim;
    public GameObject loseAnim;
    public GameObject spawnerAlert;
    public GameObject finalBeginButton;
    public GameObject inFinalImg;
    public Text roundText;

    bool canAlert;

    public GameObject mainCastle;
    enemyManager enemy;
    public placeManager place;
    public pathPlaceManager castlePlace;

    int totalCaptureCastles;
    public bool startedFinal;
    public GameObject castleConfetti;
    public GameObject explosiveConfetti;

    public GameObject conqueredLandUi;
    public Text conqueredText;

    public Text winText;
    levelLoader level;
    GameObject zues;

    saveLoad save;
    kingdomTracker kingdomTrack;

    public GameObject welcomeHomeObj;

    int spawnAmount;
    private void Awake()
    {
        winText.text = "Victory!";
        save = FindObjectOfType<saveLoad>();
        kingdomTrack = save.gameObject.GetComponent<kingdomTracker>();

        if (save.levelsBeat >= save.findOurBuild())
        {
            conqueredLandUi.SetActive(true);
            conqueredText.text = "It seems " + PlayerPrefs.GetString("kingdomName") +" Dynasty already owns this land";
        }
        else
        {
            conqueredLandUi.SetActive(false);
        }

        if(save.findOurBuild() < 6)
        {
            spawnAmount = 30;
        }
        else
        {
            if(save.findOurBuild() >= 6)
            {
                spawnAmount = 35;
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        finalBeginButton.SetActive(false);
        inFinalImg.SetActive(false);

        enemy = GetComponent<enemyManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if (mainCastle == null)
            gameLost = true;

        if (startedFinal && !IsInvoking("checkForWin"))
        {
            Invoke("checkForWin", 1);
        }

        if (gameLost && !animatedLoss)
        {
            loseAnim.SetActive(true);
            animatedLoss = true;

            if (castlePlace.placingCast || place.placing)
            {
                castlePlace.placingCast = false;
                place.placing = false;
            }
        }
        if (gameWon && !animatedWin)
        {
            if (SceneManager.GetActiveScene().buildIndex <= 17)
            {
                winAnim.SetActive(true);
            }
            else
            {
                save.levelsBeat = 0;
                welcomeHomeObj.SetActive(true);
                save.saveFirst();
            }

            animatedWin = true;
            spawnConfettiWin();

            save.saveData();

            int randomWinSound = Random.Range(0, 3);
            FindObjectOfType<musicManager>().fadeOutAudio();

            switch (randomWinSound)
            {
                case 0:
                    FindObjectOfType<audioManager>().play("winSound0");
                    break;
                case 1:
                    FindObjectOfType<audioManager>().play("winSound1");
                    break;
                case 2:
                    FindObjectOfType<audioManager>().play("winSound2");
                    break;
            }

            if (castlePlace.placingCast || place.placing)
            {
                castlePlace.placingCast = false;
                place.placing = false;
            }
        }

        if (FindAllCastles() == totalCaptureCastles && !startedFinal)
        {
            finalBeginButton.SetActive(true);
        }
    }
    public void toMenu()
    {
        SceneManager.LoadScene(sceneName: "StartMenu");
    }

    public int FindAllCastles()
    {
        GameObject[] castles;
        captureCastleCont[] attacks;
        attacks = FindObjectsOfType<captureCastleCont>();

        castles = new GameObject[attacks.Length];
        for (int i = 0; i < castles.Length; i++)
            castles[i] = attacks[i].gameObject;

        totalCaptureCastles = castles.Length;

        int capturedCastles = 0;
        Vector3 position = transform.position;
        foreach (GameObject go in castles)
        {
            if (go.GetComponent<captureCastleCont>().captured)
                capturedCastles += 1;
        }
        return capturedCastles;
    }

    public void startFinalRound(int action)
    {
        enemySpawn[] spawner;
        spawner = FindObjectsOfType<enemySpawn>();

        finalBeginButton.SetActive(false);
        inFinalImg.SetActive(true);

        foreach (enemySpawn sp in spawner)
        {
            switch (action)
            {
                case 0:
                    startedFinal = true;
                    sp.miniCoolTime = .08f;
                    sp.cooling = false;
                    sp.miniCooling = false;
                    sp.spawnTiming = false;
                    sp.troopsToSpawn = spawnAmount;
                    sp.StartCoroutine(sp.hyperCool());
                    break;

                case 1:
                    sp.spawnFertile = false;
                    break;
            }
        }
    }

    public GameObject FindClosestEnemy()
    {
        GameObject[] gos;
        gos = GameObject.FindGameObjectsWithTag("enemy");
        GameObject closest = null;
        float distance = Mathf.Infinity;
        Vector3 position = transform.position;
        foreach (GameObject go in gos)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance)
            {
                closest = go;
                distance = curDistance;
            }
        }
        return closest;
    }

    void checkForWin()
    {
        if(FindClosestEnemy() == null)
        {
            gameWon = true;
        }
    }

    void spawnConfettiWin()
    {
        GameObject[] mainCastle;
        GameObject[] castles;
        GameObject[] allCastles;
        captureCastleCont[] attacks;
        mainCastle = GameObject.FindGameObjectsWithTag("mainCastle");

        attacks = FindObjectsOfType<captureCastleCont>();

        castles = new GameObject[attacks.Length];
        for (int i = 0; i < castles.Length; i++)
            castles[i] = attacks[i].gameObject;

        allCastles = castles.Concat(mainCastle).ToArray();
        Vector3 position = transform.position;

        foreach (GameObject go in allCastles)
        {
            Invoke("spawnExplosiveConfetti", Random.Range(0, 3));
            Invoke("spawnExplosiveConfetti", Random.Range(1, 4));
            Invoke("spawnExplosiveConfetti", Random.Range(3, 6));
            Invoke("spawnExplosiveConfetti", Random.Range(5, 12));
            Invoke("spawnExplosiveConfetti", Random.Range(11, 17));

            if (go.tag == "tower")
            {
                if (go.GetComponent<captureCastleCont>().captured)
                {
                    Vector3 confettiPos = new Vector3(go.transform.position.x, go.transform.position.y + 6, go.transform.position.z);

                    GameObject ourConfet = Instantiate(castleConfetti, confettiPos, new Quaternion(0, 0, 0, 0));
                    Destroy(ourConfet, 20);
                    FindObjectOfType<audioManager>().play("partyPopper");
                }
            }
            else
            {
                Vector3 confettiPos = new Vector3(go.transform.position.x, go.transform.position.y + 6, go.transform.position.z);

                GameObject ourConfet = Instantiate(castleConfetti, confettiPos, new Quaternion(0, 0, 0, 0));
                Destroy(ourConfet, 20);
                FindObjectOfType<audioManager>().play("partyPopper");
            }
        }

    }

    void spawnExplosiveConfetti()
    {
        Vector3 confettiPosRand = new Vector3(Random.Range(-115, 81), Random.Range(15, 40), Random.Range(-104, 118));
        GameObject newConfetti = Instantiate(explosiveConfetti, confettiPosRand, Quaternion.identity);

        int scaleAddOn = Random.Range(0, 6);
        newConfetti.transform.localScale += new Vector3(scaleAddOn, scaleAddOn, scaleAddOn);

        Destroy(newConfetti, 6);
        FindObjectOfType<audioManager>().play("partyPopper");
    }

}
