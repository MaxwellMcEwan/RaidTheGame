﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boltController : MonoBehaviour
{
    bool hit;

    // Start is called before the first frame update
    void Start()
    {
        hit = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!hit && FindClosestEnemy() != null)
        {
            Debug.Log("aha ha ah running");
            GameObject targetParent = FindClosestEnemy().gameObject;
            Transform targetTrans = targetParent.transform.GetChild(0).transform;
            Vector3 targetPoint = new Vector3(targetTrans.position.x, targetTrans.position.y, targetTrans.position.z);

            transform.position = Vector3.MoveTowards(transform.position, targetPoint, Mathf.Infinity);
            transform.LookAt(targetPoint);
        }

    }

    GameObject FindClosestEnemy()
    {
        GameObject[] gos;
        gos = GameObject.FindGameObjectsWithTag("enemy");
        GameObject closest = null;
        float distance = Mathf.Infinity;
        Vector3 position = transform.position;
        foreach (GameObject go in gos)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance)
            {
                closest = go;
                distance = curDistance;
            }
        }
        return closest;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!hit)
        {
            if (other.GetComponent<Animator>() != null && other.GetComponentInParent<archerController>() !=null)
            {
                Rigidbody rigid = GetComponent<Rigidbody>();
                rigid.isKinematic = true;

                hit = true;
                transform.SetParent(other.transform);
            } else if (other.GetComponent<swordmanController>() != null && other.GetComponent<Animator>() != null)
            {
                Rigidbody rigid = GetComponent<Rigidbody>();
                rigid.isKinematic = true;

                hit = true;
                transform.SetParent(other.transform);
            }
            else if (other.GetComponent<mageController>() != null && other.GetComponent<Animator>() != null)
            {
                Rigidbody rigid = GetComponent<Rigidbody>();
                rigid.isKinematic = true;

                hit = true;
                transform.SetParent(other.transform);
            }
        }
    }
}
