﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pathController : MonoBehaviour
{
    public bool selected;

    GameObject[] arrows;

    GameObject leftArrow;
    GameObject rightArrow;
    GameObject upArrow;
    GameObject downArrow;

    pathPlaceManager pathPlace;

    public GameObject selectedArrow;
    public Vector3 pathVecAdd;

    public Material matNorm;
    public Material matSelected;

    MeshRenderer boxMesh;

    int arrowInt;
    Vector3 polePos;
    public GameObject lampPost;
    GameObject ourLamp;
    public int sideNum;

    public bool tradeCelebrate;
    float celebrationTime;
    Animator childAnim;

    KeyCode toFirstKey = KeyCode.E;

    int arrowsRan;
    // Start is called before the first frame update
    void Start()
    {
        childAnim = transform.GetChild(0).gameObject.GetComponent<Animator>();
        celebrationTime = 1;

        if (transform.name == "firstCell")
            selected = true;

        pathPlace = GetComponentInParent<pathPlaceManager>();

        boxMesh = transform.GetChild(0).gameObject.GetComponent<MeshRenderer>();
        matNorm = boxMesh.material;

        leftArrow = transform.GetChild(1).gameObject;
        rightArrow = transform.GetChild(2).gameObject;
        upArrow = transform.GetChild(3).gameObject;
        downArrow = transform.GetChild(4).gameObject;

        arrows = new GameObject[4];

        arrows[0] = leftArrow;
        arrows[1] = rightArrow;
        arrows[2] = upArrow;
        arrows[3] = downArrow;
    }

    // Update is called once per frame
    void Update()
    {
        if (tradeCelebrate)
        {
            childAnim.SetBool("celebrating", true);
            StartCoroutine(celebrationOver());
        }

        if (selected && pathPlace.placingCast)
        {
            arrowsRan = 0;
            if (boxMesh.material != matSelected)
            {
                boxMesh.material = matSelected;
            }


            if (Input.GetKeyUp(toFirstKey))
            {
                pathPlace.switchToFirst(gameObject);
            }

            foreach (GameObject arrow in arrows)
            {
                pathArrowController arrowController = arrow.GetComponent<pathArrowController>();

                if (arrowController.avaliable && !arrowController.isActiveAndEnabled)
                    arrowController.gameObject.SetActive(true);


                if (pathPlace.pathCooled)
                {
                    if (Input.GetKey(KeyCode.LeftArrow) && arrow == leftArrow)
                    {
                        pathArrowController ArrowCont = leftArrow.GetComponent<pathArrowController>();
                        selectedArrow = leftArrow;
                        StartCoroutine(pathPlace.pathCooler());

                        if (!ArrowCont.touchingPath && !ArrowCont.immoveable && pathPlace.moneyCount >= pathPlace.pathCost)
                        {
                            arrowInt = 0;
                            pathVecAdd = new Vector3(-3, 0, 0);
                            pathPlace.buildPath(gameObject);

                            selected = false;

                            pathPlace.buildMode = true;
                        }
                        else if(ArrowCont.touchingPath)
                        {
                            pathPlace.pathSwitched(ArrowCont.pathColl, gameObject);
                            selected = false;
                        } else if(pathPlace.moneyCount < pathPlace.pathCost)
                        {
                            FindObjectOfType<placeManager>().tooPoor = true;
                        }
                    }

                    if (Input.GetKey(KeyCode.RightArrow) && arrow == rightArrow)
                    {
                        pathArrowController ArrowCont = rightArrow.GetComponent<pathArrowController>();
                        selectedArrow = rightArrow;
                        StartCoroutine(pathPlace.pathCooler());

                        if (!ArrowCont.touchingPath && !ArrowCont.immoveable && pathPlace.moneyCount >= pathPlace.pathCost)
                        {
                            arrowInt = 1;

                            pathVecAdd = new Vector3(3, 0, 0);
                            pathPlace.buildPath(gameObject);

                            selected = false;

                            pathPlace.buildMode = true;
                        }
                        else if(ArrowCont.touchingPath)
                        {
                            pathPlace.pathSwitched(ArrowCont.pathColl, gameObject);
                            selected = false;
                        }
                        else if (pathPlace.moneyCount < pathPlace.pathCost)
                        {
                            FindObjectOfType<placeManager>().tooPoor = true;
                        }
                    }

                    if (Input.GetKey(KeyCode.UpArrow) && arrow == upArrow)
                    {
                        pathArrowController ArrowCont = upArrow.GetComponent<pathArrowController>();
                        selectedArrow = upArrow;
                        StartCoroutine(pathPlace.pathCooler());

                        if (!ArrowCont.touchingPath && !ArrowCont.immoveable && pathPlace.moneyCount >= pathPlace.pathCost)
                        {
                            arrowInt = 2;

                            pathVecAdd = new Vector3(0, 0, 3);
                            pathPlace.buildPath(gameObject);

                            selected = false;

                            pathPlace.buildMode = true;
                        }
                        else if(ArrowCont.touchingPath)
                        {
                            pathPlace.pathSwitched(ArrowCont.pathColl, gameObject);
                            selected = false;
                        }
                        else if (pathPlace.moneyCount < pathPlace.pathCost)
                        {
                            FindObjectOfType<placeManager>().tooPoor = true;
                        }
                    }

                    if (Input.GetKey(KeyCode.DownArrow) && arrow == downArrow)
                    {
                        pathArrowController ArrowCont = downArrow.GetComponent<pathArrowController>();
                        selectedArrow = downArrow;
                        StartCoroutine(pathPlace.pathCooler());

                        if (!ArrowCont.touchingPath && !ArrowCont.immoveable && pathPlace.moneyCount >= pathPlace.pathCost)
                        {
                            arrowInt = 3;

                            pathVecAdd = new Vector3(0, 0, -3);
                            pathPlace.buildPath(gameObject);

                            selected = false;

                            pathPlace.buildMode = true;
                        }
                        else if (ArrowCont.touchingPath)
                        {
                            pathPlace.pathSwitched(ArrowCont.pathColl, gameObject);
                            selected = false;
                        }
                        else if (pathPlace.moneyCount < pathPlace.pathCost)
                        {
                            FindObjectOfType<placeManager>().tooPoor = true;
                        }
                    }
                }
            }
        }
        else
        {
            if (boxMesh.material != matNorm)
            {
                boxMesh.material = matNorm;
            }

            if (arrowsRan < 4)
            {
                foreach (GameObject arrow in arrows)
                {
                    arrowsRan += 1;
                    if (arrow.GetComponent<pathArrowController>().enabled)
                    {
                        pathArrowController arrowController = arrow.GetComponent<pathArrowController>();
                        arrowController.gameObject.SetActive(false);
                    }
                }
            }
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "selector" && other.GetComponent<tradeRouteController>() != null)
        {
            if (!other.gameObject.GetComponent<tradeRouteController>().connected)
            {
                tradeRouteController tradeRoute = other.gameObject.GetComponent<tradeRouteController>();
                tradeRoute.connected = true;
            }
        }
    }

    public void spawnPost()
    {
        Vector3 upRot = new Vector3(0, 180, 0);
        Vector3 downRot = new Vector3(0, 0, 0);
        Vector3 leftRot = new Vector3(0, 90, 0);
        Vector3 rightRot = new Vector3(0, -90, 0);

        switch (arrowInt)
        {
            case 0:
                switch (sideNum)
                {
                    case 0:
                        if (!upArrow.GetComponent<pathArrowController>().touchingPath)
                        {
                            ourLamp = Instantiate(lampPost, upArrow.transform.position, new Quaternion(0, 0, 0, 0));
                            ourLamp.transform.GetChild(0).transform.Rotate(upRot);
                        }
                        break;
                    case 1:
                        if (!downArrow.GetComponent<pathArrowController>().touchingPath)
                        {
                            ourLamp = Instantiate(lampPost, downArrow.transform.position, new Quaternion(0, 0, 0, 0));
                            ourLamp.transform.GetChild(0).transform.Rotate(downRot);
                        }
                        break;
                }

                break;

            case 1:

                switch (sideNum)
                {
                    case 0:
                        if (!upArrow.GetComponent<pathArrowController>().touchingPath)
                        {
                            ourLamp = Instantiate(lampPost, upArrow.transform.position, new Quaternion(0, 0, 0, 0));
                            ourLamp.transform.GetChild(0).transform.Rotate(upRot);
                        }
                        break;
                    case 1:
                        if (!downArrow.GetComponent<pathArrowController>().touchingPath)
                        {
                            ourLamp = Instantiate(lampPost, downArrow.transform.position, new Quaternion(0, 0, 0, 0));
                            ourLamp.transform.GetChild(0).transform.Rotate(downRot);
                        }
                        break;
                }
                break;

            case 2:
                switch (sideNum)
                {
                    case 0:
                        if (!leftArrow.GetComponent<pathArrowController>().touchingPath)
                        {
                            ourLamp = Instantiate(lampPost, leftArrow.transform.position, new Quaternion(0, 0, 0, 0));
                            ourLamp.transform.GetChild(0).transform.Rotate(leftRot);
                        }
                        break;
                    case 1:
                        if (!rightArrow.GetComponent<pathArrowController>().touchingPath)
                        {
                            ourLamp = Instantiate(lampPost, rightArrow.transform.position, new Quaternion(0, 0, 0, 0));
                            ourLamp.transform.GetChild(0).transform.Rotate(rightRot);
                        }
                        break;
                }
                break;

            case 3:
                switch (sideNum)
                {
                    case 0:
                        if (!leftArrow.GetComponent<pathArrowController>().touchingPath)
                        {
                            ourLamp = Instantiate(lampPost, leftArrow.transform.position, new Quaternion(0, 0, 0, 0));
                            ourLamp.transform.GetChild(0).transform.Rotate(leftRot);
                        }
                        break;
                    case 1:
                        if (!rightArrow.GetComponent<pathArrowController>().touchingPath)
                        {
                            ourLamp = Instantiate(lampPost, rightArrow.transform.position, new Quaternion(0, 0, 0, 0));
                            ourLamp.transform.GetChild(0).transform.Rotate(rightRot);
                        }
                        break;
                }
                break;
        }

        if (ourLamp != null)
            ourLamp.GetComponent<lampPostController>().realSwitch(pathPlace.lightMode);
    }

    IEnumerator celebrationOver()
    {
        yield return new WaitForSeconds(celebrationTime);
        tradeCelebrate = false;
        childAnim.SetBool("celebrating", false);
    }
}
