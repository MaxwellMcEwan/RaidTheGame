﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyAnimationController : MonoBehaviour
{
    int ourType;
    GameObject child;
    Animator anim;

    bool explosionCool;
    public bool explosion;
    public bool stunned;
    bool choseSign;

    public GameObject atHolder;
    public GameObject hashHolder;
    public GameObject percentHolder;

    GameObject signal;
    Animator sigAnimator;

    public int maxStunTime = 3;
    float stunTime;

    bool closedSignal;

    int ourSignal;
    Vector3 signalSpawn;

    bool usAlive;

    archerController archCont;
    swordmanController swordCont;
    mageController mageCont;
    // Start is called before the first frame update
    void Start()
    {
        usAlive = true;
        stunTime = 0;
        findOurType();


        child = transform.GetChild(0).gameObject;
        anim = child.GetComponent<Animator>();

        ourSignal = Random.Range(0, 3);

        signalSpawn = new Vector3(child.transform.position.x, child.transform.position.y + 6, child.transform.position.z);


        switch (ourSignal)
        {
            case 0:
                signal = Instantiate(atHolder, signalSpawn, transform.rotation);
                signal.transform.SetParent(child.transform);

                break;

            case 1:
                signal = Instantiate(hashHolder, signalSpawn, transform.rotation);
                signal.transform.SetParent(child.transform);

                break;

            case 2:
                signal = Instantiate(percentHolder, signalSpawn, transform.rotation);
                signal.transform.SetParent(child.transform);

                break;

        }

        switch (ourType)
        {
            case 0:
                GameObject holder = transform.GetChild(0).transform.GetChild(3).gameObject;

                sigAnimator = holder.transform.GetChild(0).GetComponent<Animator>();
                swordCont = GetComponent<swordmanController>();
                break;
            case 1:
                GameObject holderArch = transform.GetChild(0).transform.GetChild(3).gameObject;

                sigAnimator = holderArch.transform.GetChild(0).GetComponent<Animator>();
                archCont = GetComponent<archerController>();
                break;
            case 2:
                GameObject holderMage = transform.GetChild(0).transform.GetChild(1).gameObject;

                sigAnimator = holderMage.transform.GetChild(0).GetComponent<Animator>();
                mageCont = GetComponent<mageController>();
                break;

            default:
                break;
        }

        signal.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (!usAlive)
            return;

        stunTime -= 1 * Time.deltaTime;

        if (stunTime <= 0)
        {
            stunTime = 0;
            stunned = false;
        }

        if (stunned && usAlive)
        {
            signal.SetActive(true);
            closedSignal = false;
            sigAnimator.SetBool("closed", false);
        }
        else
        {
            if (!closedSignal && usAlive)
            {
                sigAnimator.SetBool("closed", true);
                StartCoroutine(closeDelay());
            }
        }

        controlAnims();
    }

    void controlAnims()
    {
        switch (ourType)
        {
            case 0:
                swordmanController swordman = GetComponent<swordmanController>();

                if (!swordman.died)
                {
                    if (swordman.attacking)
                    {
                        anim.SetBool("fighting", true);
                    }
                    else
                    {
                        anim.SetBool("fighting", false);
                    }


                }
                else
                {
                    usAlive = false;
                    anim.SetBool("died", true);
                    return;
                }

                break;

            case 1:
                archerController archer = GetComponent<archerController>();

                if (!archer.died)
                {
                    if (archer.attacking)
                    {
                        anim.SetBool("firing", true);
                    }
                    else
                    {
                        anim.SetBool("firing", false);
                    }
                }
                else
                {
                    usAlive = false;
                    anim.SetBool("died", true);
                    return;
                }

                break;

            case 2:
                mageController mage = GetComponent<mageController>();

                if (!mage.died)
                {
                    if (mage.casting)
                    {
                        anim.SetBool("casting", true);
                    }
                    else
                    {
                        anim.SetBool("casting", false);
                    }
                }
                else
                {
                    usAlive = false;
                    anim.SetBool("died", true);
                    return;
                }

                break;
        }
    }

    public void explosionDelay()
    {
        stunTime = maxStunTime;
        stunned = true;
    }

    void findOurType()
    {
        if (GetComponent<swordmanController>() != null)
            ourType = 0;
        else if (GetComponent<archerController>() != null)
            ourType = 1;
        else if (GetComponent<mageController>() != null)
            ourType = 2;
    }

    IEnumerator closeDelay()
    {
        closedSignal = true;
        yield return new WaitForSeconds(.5f);
        signal.SetActive(false);
    }
}
