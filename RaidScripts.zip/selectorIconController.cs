﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class selectorIconController : MonoBehaviour
{
    Animator animat;

    public towerUpgrader upgrader;

    public bool closed;

    private void Awake()
    {
        animat = GetComponentInChildren<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (upgrader.startClose)
        {
            StartCoroutine(closeDelay());
        }

    }

    IEnumerator closeDelay()
    {
        upgrader.startClose = false;
        animat.SetBool("closed", true);

        yield return new WaitForSeconds(.38f);

        gameObject.SetActive(false);
        animat.SetBool("closed", false);
    }
}
