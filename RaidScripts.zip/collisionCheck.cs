﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collisionCheck : MonoBehaviour
{
    public bool colliding;

    public Material matNorm0;
    public Material matRed0;

    public Material matNorm1;
    public Material matRed1;

    MeshRenderer meshRend0;
    MeshRenderer meshRend1;

    public bool meshActive;
    bool hasChild;

    public bool feelerColliding;
    public GameObject parentOfFeeler;

    towerSelector selector;

    treeController treeCont;

    public bool underCount;
    private void Awake()
    {
        if (tag == "tree" && GetComponent<treeController>() != null)
            treeCont = GetComponent<treeController>();

        if (transform.childCount > 0)
        {
            if (transform.GetChild(0).gameObject)
            {
                if (name == "wallEmpty")
                {
                    selector = GetComponentInParent<towerSelector>();
                    meshRend0 = transform.GetChild(0).gameObject.GetComponent<MeshRenderer>();
                    meshRend1 = transform.GetChild(1).gameObject.GetComponent<MeshRenderer>();

                    matNorm0 = meshRend0.material;
                }
                else
                {
                    hasChild = true;
                    meshRend1 = transform.GetChild(0).gameObject.GetComponentInChildren<MeshRenderer>();

                    matNorm1 = meshRend1.material;
                }
            }
        }
        

        if (GetComponentInParent<pathPlaceManager>() != null && name == "cellSelector")
        {
            meshRend0 = transform.GetChild(0).gameObject.GetComponent<MeshRenderer>();
        }
        else
        {
            if(name != "wallEmpty")
                meshRend0 = GetComponent<MeshRenderer>();
        }

        if (tag != "tree" && name != "wallEmpty")
        {
            matNorm0 = meshRend0.material;
        }
    }

    // Start is called before the first frame update
    private void OnDisable()
    {
        colliding = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (tag != "tree" && name != "wallEmpty")
        {
            if (meshRend0.enabled)
                meshActive = true;
            else
                meshActive = false;

            if (colliding || underCount)
            {
                meshRend0.material = matRed0;
                if (hasChild)
                {
                    meshRend1.material = matRed1;
                }
            }
            else if (!colliding && !underCount)
            {
                meshRend0.material = matNorm0;
                if (hasChild)
                {
                    meshRend1.material = matNorm1;
                }
            }
        } else if (name == "wallEmpty")
        {
            if (colliding)
            {
                meshRend0.material = matRed0;
                meshRend1.material = matRed0;
            }
            else
            {
                meshRend0.material = matNorm0;
                meshRend1.material = matNorm0;
            }
        }
    }


    private void OnTriggerStay(Collider other)
    {
        if (gameObject.tag == "wall")
        {
            if (other.tag != "ground" && other.tag != "mound" && other.tag != "tree" && other.tag != "selector")
            {
                if (other.name == "feelerL" || other.name == "feelerR")
                {
                    if(other.transform.rotation != transform.rotation)
                    {
                        selector.wallForm = 1;
                    }
                    else
                    {
                        selector.wallForm = 0;
                    }
                    feelerColliding = true;
                }
                else
                {
                    colliding = true;
                }
            }
        }
        else
        {
            if (other.tag != "ground" && other.tag != "tree" && other.name != "feelerL" && other.name != "feelerR")
            {
                if (tag == "path" && other.tag != "path")
                {
                    colliding = true;

                }
                else if (tag != "path" && other.tag != "selector")
                {

                    if (tag == "tree" && GetComponent<treeController>() != null)
                    {
                        if (other.tag != "mound")
                        {
                            colliding = true;
                            treeCont.collisionUpdate();
                        }
                    }
                    else if(tag == "tree" && GetComponent<treeController>() == null)
                    {
                        colliding = true;
                    }
                    else if (tag!= "tree")
                    {
                        colliding = true;
                    }
                }
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (tag == "wall")
        {
            if (other.tag != "ground" && other.tag != "mound" && other.tag != "tree")
            {
                if (other.name == "feelerL" || other.name == "feelerR")
                {
                    selector.wallForm = 0;
                    feelerColliding = false;
                }
                else
                {
                    colliding = false;
                }

            }
        }
        else
        {
            if (other.tag != "ground" && other.tag != "tree")
            {
                if (tag == "path" && other.tag != "path")
                {
                    colliding = false;

                }
                else if (tag != "path"  && other.tag != "selector")
                {
                    colliding = false;

                    if(tag == "tree" && GetComponent<treeController>() != null)
                    {
                        treeCont.collisionUpdate();
                    }
                }
            }
        }
    }
}
