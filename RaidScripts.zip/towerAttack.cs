﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class towerAttack : MonoBehaviour
{
    int towerType;
    int enemyType;

    float timeTillShoot;
    public float animTime;

    public GameObject ribbonSmoke;
    public GameObject bloodPool;

    public GameObject closestEnemy;
    public float enemyDist;

    bool attackCooling;

    float cooldownTime;

    public bool startAttackAnim;
    int ourDamage;

    public float ourLookRaidus;

    lightManager lightMan;
    gameManager gameMan;

    // Start is called before the first frame update
    void Start()
    {
        lightMan = FindObjectOfType<lightManager>();
        gameMan = FindObjectOfType<gameManager>();

        attackCooling = false;
        FindClosestEnemy();
    }

    // Update is called once per frame
    void Update()
    {

        if (lightMan.night || closestEnemy != null)
        {
            if (closestEnemy != null)
            {
                enemyDist = Vector3.Distance(closestEnemy.transform.position, transform.position);

                if (towerType == 0)
                    findType();
                else
                    enemySearch();
            }

        }

        if (!IsInvoking("FindClosestEnemy"))
            Invoke("FindClosestEnemy", 1);

    }


    void enemySearch()
    {
        findEnemyType();
        switch (towerType)
        {
            case 1:
                archerTower archer = GetComponent<archerTower>();

                if (!archer.construction)
                {
                    if (enemyDist <= archer.lookRadius)
                    {
                        if (!attackCooling)
                        {
                            ourLookRaidus = archer.lookRadius;
                            cooldownTime = archer.coolDown;

                            switch (archer.level)
                            {
                                case 4:

                                    animTime = .5f;

                                    break;

                                default:

                                    animTime = 1f;

                                    break;
                            }

                            startAttackAnim = true;

                            ourDamage = archer.damage;

                            StartCoroutine(AnimAttackDelay());

                            FindClosestEnemy();
                        }
                    }
                }

                break;

            case 2:
                canonTower canon = GetComponent<canonTower>();

                animTime = 2;

                if (!canon.construction)
                {
                    if (enemyDist <= canon.lookRadius)
                    {
                        if (!attackCooling)
                        {
                            ourLookRaidus = canon.lookRadius;
                            cooldownTime = canon.coolDown;
                            animTime = 2;

                            startAttackAnim = true;

                            ourDamage = 0;

                            StartCoroutine(AnimAttackDelay());
                            FindClosestEnemy();
                        }
                    }
                }

                break;

            case 3:
                mageTower mage = GetComponent<mageTower>();

                if (!mage.construction)
                {
                    if (enemyDist <= mage.lookRadius)
                    {
                        if (!attackCooling)
                        {
                            ourLookRaidus = mage.lookRadius;
                            animTime = .2f;

                            startAttackAnim = true;

                            cooldownTime = mage.cooldown;
                            ourDamage = mage.damage;

                            StartCoroutine(AnimAttackDelay());
                            FindClosestEnemy();
                        }
                    }
                }


                break;
        }
    }


    void findType()
    {
        if (GetComponent<archerTower>() != null)
            towerType = 1;
        else
            if (GetComponent<canonTower>() != null)
            towerType = 2;
        else
            if (GetComponent<mageTower>() != null)
            towerType = 3;
    }

    void findEnemyType()
    {
        if (closestEnemy.GetComponent<swordmanController>() != null)
        {
            enemyType = 1;
        }
        else if (closestEnemy.GetComponent<archerController>() != null)
        {
            enemyType = 2;
        }
        else if (closestEnemy.GetComponent<mageController>() != null)
        {
            enemyType = 3;
        }
    }

    IEnumerator AnimAttackDelay()
    {
        StartCoroutine(cooldown());

        yield return new WaitForSeconds(animTime);

        if (closestEnemy != null && enemyDist <= ourLookRaidus)
        {
            switch (enemyType)
            {
                case 1:

                    swordmanController swordman = closestEnemy.GetComponent<swordmanController>();
                    if (swordman != null)
                    {

                        swordman.health -= ourDamage;

                        if (swordman.health <= 0)
                        {
                            switch (towerType)
                            {
                                case 3:
                                    GameObject swordChild = swordman.transform.GetChild(0).gameObject;
                                    Vector3 randomSpawn = new Vector3(0, Random.Range(2, 4), 0);

                                    GameObject spawnedSmoke = Instantiate(ribbonSmoke, swordChild.transform.position + randomSpawn, new Quaternion(0, 0, 0, 0));
                                    spawnedSmoke.transform.SetParent(swordChild.transform);

                                    break;
                            }
                        }
                    }
                    break;

                case 2:

                    archerController enemyArcher = closestEnemy.GetComponent<archerController>();
                    if (enemyArcher != null)
                    {
                        enemyArcher.health -= ourDamage;

                        if (enemyArcher.health <= 0)
                        {
                            switch (towerType)
                            {
                                case 3:

                                    GameObject archerChild = enemyArcher.transform.GetChild(0).gameObject;
                                    Vector3 randomSpawn = new Vector3(0, Random.Range(2, 4), 0);

                                    GameObject spawnedSmoke = Instantiate(ribbonSmoke, archerChild.transform.position + randomSpawn, new Quaternion(0, 0, 0, 0));
                                    spawnedSmoke.transform.SetParent(archerChild.transform);

                                    break;
                            }
                        }
                    }
                    break;

                case 3:

                    mageController enemyMage = closestEnemy.GetComponent<mageController>();
                    if (enemyMage != null)
                    {
                        enemyMage.health -= ourDamage;

                        if (enemyMage.health <= 0)
                        {
                            switch (towerType)
                            {

                                case 3:
                                    GameObject mageChild = enemyMage.transform.GetChild(0).gameObject;
                                    Vector3 randomSpawn = new Vector3(0, Random.Range(2, 4), 0);

                                    GameObject spawnedSmoke = Instantiate(ribbonSmoke, mageChild.transform.position + randomSpawn, new Quaternion(0, 0, 0, 0));
                                    spawnedSmoke.transform.SetParent(mageChild.transform);

                                    break;
                            }
                        }
                    }
                    break;
            }
        }
    }

    IEnumerator cooldown()
    {
        attackCooling = true;

        yield return new WaitForSeconds(cooldownTime + animTime);

        attackCooling = false;
    }

    public void FindClosestEnemy()
    {
        GameObject[] gos;
        gos = GameObject.FindGameObjectsWithTag("enemy");

        closestEnemy = null;
        float distance = Mathf.Infinity;
        Vector3 position = transform.position;
        foreach (GameObject go in gos)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance)
            {
                closestEnemy = go;
                distance = curDistance;
            }
        }
    }
}
