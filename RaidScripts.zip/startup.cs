﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class startup : MonoBehaviour
{
    mouseFollow mouseFollow;
    castleManager castle;

    public bool setup;
    bool castlePlaced;

    public GameObject towerSelect;
    public GameObject placeGuide;

    // Start is called before the first frame update
    void Start()
    {
        castle = GetComponent<castleManager>();

        placeGuide.SetActive(true);
        setup = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!setup)
        {
            if (!placeGuide.GetComponent<collisionCheck>().colliding)
            {
                placeGuide.SetActive(false);

                setup = true;

                StartCoroutine(activateTower());

                StartCoroutine(castle.upgrade0());
            }

        }
    }

    IEnumerator activateTower()
    {
        yield return new WaitForEndOfFrame();

        towerSelect.SetActive(true);
    }
}
