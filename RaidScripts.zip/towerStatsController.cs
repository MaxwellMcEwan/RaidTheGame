﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class towerStatsController : MonoBehaviour
{
    public Text towerInfo;
    public Text statUp;
    public Text healthText;
    public Text attackText;
    public Text fireRateText;
    public Text rangeText;
    public Text actionsText;
    public Text upgradeText;
    public Text deleteText;
    public Text repairText;

    public Image statBacking;

    Animator anim;
    bool animatedClose;

    int towerLevel;
    int upgradeCost;
    int uiState;

    bool hasOpened;
    bool hasClosed;

    GameObject selectedTower;
    public GameObject selectorIcon;

    bool iconOpened;
    bool iconClosed;

    [HideInInspector]public towerUpgrader upgrader;

    [HideInInspector]public static bool statsBack;

    // Start is called before the first frame update
    void Start()
    {
        statsBack = false;

        anim = GetComponent<Animator>();

        towerInfo.gameObject.SetActive(false);
        statUp.gameObject.SetActive(false);
        healthText.gameObject.SetActive(false);
        attackText.gameObject.SetActive(false);
        fireRateText.gameObject.SetActive(false);
        rangeText.gameObject.SetActive(false);
        actionsText.gameObject.SetActive(false);
        upgradeText.gameObject.SetActive(false);
        deleteText.gameObject.SetActive(false);
        repairText.gameObject.SetActive(false);

        statBacking.gameObject.SetActive(false);

    }

    // Update is called once per frame
    void Update()
    {
        if (upgrader.selectedTower != null)
        {
            selectedTower = upgrader.selectedTower;
            uiState = 1;
        }
        else
        {
            uiState = 0;
        }

        uiSwitch();
    }

    void uiSwitch()
    {
        switch (uiState)
        {
            case 0:
                iconOpened = false;
                if (animatedClose == true)
                {
                    towerInfo.gameObject.SetActive(false);
                    statUp.gameObject.SetActive(false);
                    healthText.gameObject.SetActive(false);
                    attackText.gameObject.SetActive(false);
                    fireRateText.gameObject.SetActive(false);
                    rangeText.gameObject.SetActive(false);
                    actionsText.gameObject.SetActive(false);
                    upgradeText.gameObject.SetActive(false);
                    deleteText.gameObject.SetActive(false);
                    repairText.gameObject.SetActive(false);

                    statBacking.gameObject.SetActive(false);

                    selectorIcon.SetActive(false);
                }
                else
                {
                    anim.SetBool("open", false);
                    StartCoroutine(closeDelay());

                }

                break;

            case 1:
                animatedClose = false;

                anim.SetBool("open", true);

                towerInfo.gameObject.SetActive(true);
                statUp.gameObject.SetActive(true);
                healthText.gameObject.SetActive(true);
                attackText.gameObject.SetActive(true);
                fireRateText.gameObject.SetActive(true);
                rangeText.gameObject.SetActive(true);
                actionsText.gameObject.SetActive(true);
                upgradeText.gameObject.SetActive(true);
                deleteText.gameObject.SetActive(true);

                if (statsBack)
                {
                    statBacking.gameObject.SetActive(true);
                }
                else
                {
                    statBacking.gameObject.SetActive(false);
                }

                selectorIcon.transform.position = new Vector3(selectedTower.transform.position.x, selectedTower.transform.position.y + 1, selectedTower.transform.position.z);

                if (!iconOpened)
                {
                    selectorIcon.SetActive(true);
                    iconOpened = true;
                }


                switch (upgrader.towerType)
                {
                    case 0:
                        archerTower archer = selectedTower.GetComponent<archerTower>();

                        if (archer.health < archer.maxHealth)
                        {
                            if (!archer.recentlyHit)
                            {
                                repairText.gameObject.SetActive(true);

                                repairText.text = "R to repair: " + upgrader.costToRepair + " Coin";
                            }
                        }
                        else
                        {
                            repairText.gameObject.SetActive(false);
                        }

                        if (archer.construction)
                        {
                            upgradeText.text = "(Under Construction)";
                        }

                        towerLevel = archer.level;

                        if (upgrader.mainCastleUpgradedEnough)
                        {
                            upgradeText.color = Color.white;
                            if (towerLevel == 0)
                            {
                                upgradeCost = upgrader.upgrade0Cost;

                                if (!archer.construction)
                                {
                                    upgradeText.gameObject.SetActive(true);
                                    upgradeText.text = "Press F To Upgrade: " + upgradeCost + " Coin";
                                }
                            }
                            else if (towerLevel == 1)
                            {
                                upgradeCost = upgrader.upgrade1Cost;

                                if (!archer.construction)
                                {
                                    upgradeText.gameObject.SetActive(true);
                                    upgradeText.text = "Press F To Upgrade: " + upgradeCost + " Coin";
                                }
                            }
                            else if (towerLevel == 2)
                            {
                                upgradeCost = upgrader.upgrade2Cost;

                                if (!archer.construction)
                                {
                                    upgradeText.gameObject.SetActive(true);
                                    upgradeText.text = "Press 5 or 6 To Upgrade: " + upgradeCost + " Coin";
                                }
                            }
                        }
                        else
                        {
                            upgradeText.text = "Upgrade Kingdom to level " + upgrader.mainCastleLvlUp;
                        }

                        int archerLevelUi;
                        int archerAOrB = 0;

                        if (archer.level + 1 < 4)
                            archerLevelUi = archer.level + 1;
                        else
                            archerLevelUi = 4;

                        if (archer.level < 3)
                        {
                            towerInfo.text = "Level " + archerLevelUi + " Archer Tower";
                        }

                        if (archer.level == 3)
                            archerAOrB = 0;
                        else if (archer.level == 4)
                            archerAOrB = 1;

                        if (archer.level < 3)
                        {
                            towerInfo.text = "Level " + archerLevelUi + " Archer Tower";
                        }
                        else
                        {
                            upgradeText.text = "Fully upgraded";
                            switch (archerAOrB)
                            {
                                case 0:
                                    towerInfo.text = "Level " + archerLevelUi + "a" + " Archer Tower";
                                    break;
                                case 1:
                                    towerInfo.text = "Level " + archerLevelUi + "b" + " Archer Tower";

                                    break;
                            }
                        }

                        attackText.text = "Attack: " + archer.damage;
                        healthText.text = "Health: " + archer.health + " / " + archer.maxHealth;
                        fireRateText.text = "Fire Rate: " + archer.coolDown + " / second";
                        rangeText.text = "Range: " + archer.lookRadius;

                        break;

                    case 1:

                        canonTower canon = selectedTower.GetComponent<canonTower>();

                        if (canon.health < canon.maxHealth)
                        {
                            if (!canon.recentlyHit)
                            {
                                repairText.gameObject.SetActive(true);

                                repairText.text = "R to repair: " + upgrader.costToRepair + " Coin";
                            }
                        }
                        else
                        {
                            repairText.gameObject.SetActive(false);
                        }

                        if (canon.construction)
                        {
                            upgradeText.text = "(Under Construction)";
                        }

                        towerLevel = canon.level;

                        if (upgrader.mainCastleUpgradedEnough)
                        {
                            if (towerLevel == 0)
                            {
                                upgradeCost = upgrader.upgrade0Cost;
                                if (!canon.construction)
                                {
                                    upgradeText.gameObject.SetActive(true);
                                    upgradeText.text = "F To Upgrade: " + upgradeCost + " Coin";
                                }
                            }
                            else if (towerLevel == 1)
                            {
                                upgradeCost = upgrader.upgrade1Cost;
                                if (!canon.construction)
                                {
                                    upgradeText.gameObject.SetActive(true);
                                    upgradeText.text = "F To Upgrade: " + upgradeCost + " Coin";
                                }
                            }
                            else if (towerLevel == 2)
                            {
                                upgradeCost = upgrader.upgrade2Cost;
                                if (!canon.construction)
                                {
                                    upgradeText.gameObject.SetActive(true);
                                    upgradeText.text = "Select 5 or 6 To Upgrade: " + upgradeCost + " Coin";
                                }
                            }
                        }
                        else
                        {
                            upgradeText.text = "Upgrade Kingdom to level " + upgrader.mainCastleLvlUp;
                        }

                        int CanonlevelUi;
                        int CanonaOrB = 0;

                        if (canon.level + 1 < 4)
                            CanonlevelUi = canon.level + 1;
                        else
                            CanonlevelUi = 4;

                        if (canon.level == 3)
                            CanonaOrB = 0;
                        else if (canon.level == 4)
                            CanonaOrB = 1;

                        if (canon.level < 3)
                        {
                            towerInfo.text = "Level " + CanonlevelUi + " Canon Tower";
                        }
                        else
                        {
                            upgradeText.text = "Fully upgraded";
                            switch (CanonaOrB)
                            {
                                case 0:
                                    towerInfo.text = "Level " + CanonlevelUi + "a" + " Canon Tower";
                                    break;
                                case 1:
                                    towerInfo.text = "Level " + CanonlevelUi + "b" + " Canon Tower";

                                    break;
                            }
                        }

                        attackText.text = "Attack: " + canon.damage;
                        healthText.text = "Health: " + canon.health + " / " + canon.maxHealth;
                        fireRateText.text = "Fire Rate: " + canon.coolDown + " / second";
                        rangeText.text = "Range: " + canon.lookRadius;

                        break;

                    case 2:

                        mageTower mage = selectedTower.GetComponent<mageTower>();

                        if (mage.health < mage.maxhealth)
                        {
                            if (!mage.recentlyHit)
                            {
                                repairText.gameObject.SetActive(true);

                                repairText.text = "R to repair: " + upgrader.costToRepair + " Coin";
                            }
                        }
                        else
                        {
                            repairText.gameObject.SetActive(false);
                        }

                        if (mage.construction)
                        {
                            upgradeText.text = "(Under Construction)";
                        }

                        towerLevel = mage.level;

                        if (upgrader.mainCastleUpgradedEnough)
                        {
                            if (towerLevel == 0)
                            {
                                upgradeCost = upgrader.upgrade0Cost;
                                if (!mage.construction)
                                {
                                    upgradeText.gameObject.SetActive(true);
                                    upgradeText.text = "F to upgrade: " + upgradeCost + " Coin";
                                }
                            }
                            else if (towerLevel == 1)
                            {
                                upgradeCost = upgrader.upgrade1Cost;
                                if (!mage.construction)
                                {
                                    upgradeText.gameObject.SetActive(true);
                                    upgradeText.text = "F to upgrade: " + upgradeCost + " Coin";
                                }
                            }
                            else if (towerLevel == 2)
                            {
                                upgradeCost = upgrader.upgrade2Cost;
                                if (!mage.construction)
                                {
                                    upgradeText.gameObject.SetActive(true);
                                    upgradeText.text = "Select 5 or 6 To Upgrade: " + upgradeCost + " Coin";
                                }
                            }
                        }
                        else
                        {
                            upgradeText.text = "Upgrade Kingdom to level " + upgrader.mainCastleLvlUp;
                        }

                        int MageLevelUi;
                        int MageAOrB = 0;

                        if (mage.level + 1 < 4)
                            MageLevelUi = mage.level + 1;
                        else
                            MageLevelUi = 4;

                        if (mage.level == 3)
                            MageAOrB = 0;
                        else if (mage.level == 4)
                            MageAOrB = 1;

                        if (mage.level < 3)
                        {
                            towerInfo.text = "Level " + MageLevelUi + " Mage Tower";
                        }
                        else
                        {
                            upgradeText.text = "Fully upgraded";
                            switch (MageAOrB)
                            {
                                case 0:
                                    towerInfo.text = "Level " + MageLevelUi + "a" + " Mage Tower";
                                    break;
                                case 1:
                                    towerInfo.text = "Level " + MageLevelUi + "b" + " Mage Tower";

                                    break;
                            }
                        }

                        attackText.text = "Attack: " + mage.damage;
                        healthText.text = "Health: " + mage.health + " / " + mage.maxhealth;
                        fireRateText.text = "Fire Rate: " + mage.cooldown + " / second";
                        rangeText.text = "Range: " + mage.lookRadius;

                        break;

                    case 3:

                        castleManager castle = selectedTower.GetComponent<castleManager>();
                        moneyCollector moneyCollector = selectedTower.GetComponent<moneyCollector>();
                        captureCastleCont captureCastleController = selectedTower.GetComponent<captureCastleCont>();

                        if (captureCastleController.captured)
                        {
                            if (castle.construction)
                            {
                                upgradeText.text = "(Under Construction)";
                            }

                            towerLevel = castle.level;

                            if (upgrader.mainCastleUpgradedEnough)
                            {
                                if (towerLevel == 0)
                                {
                                    upgradeCost = upgrader.castUpgrade0Cost;
                                    if (!castle.construction)
                                    {
                                        upgradeText.gameObject.SetActive(true);
                                        upgradeText.text = "F to upgrade: " + upgradeCost + " Coin";
                                    }
                                }
                                else if (towerLevel == 1)
                                {
                                    upgradeCost = upgrader.castUpgrade1Cost;
                                    if (!castle.construction)
                                    {
                                        upgradeText.gameObject.SetActive(true);
                                        upgradeText.text = "F to upgrade: " + upgradeCost + " Coin";
                                    }
                                }
                                else if (towerLevel == 2)
                                {
                                    upgradeCost = upgrader.castUpgrade2Cost;
                                    if (!castle.construction)
                                    {
                                        upgradeText.gameObject.SetActive(true);
                                        upgradeText.text = "Select 5 or 6 to upgrade: " + upgradeCost + " Coin";
                                    }
                                }
                            }
                            else
                            {
                                upgradeText.text = "Upgrade Kingdom to level " + upgrader.mainCastleLvlUp;
                            }

                            int castleLevelUi;
                            int castleAOrB = 0;

                            if (castle.level + 1 < 4)
                                castleLevelUi = castle.level + 1;
                            else
                                castleLevelUi = 4;

                            if (castle.level == 3)
                                castleAOrB = 0;
                            else if (castle.level == 4)
                                castleAOrB = 1;

                            if (castle.level < 3)
                            {
                                towerInfo.text = "Level " + castleLevelUi + " Castle";
                            }
                            else
                            {
                                upgradeText.gameObject.SetActive(false);
                                switch (castleAOrB)
                                {
                                    case 0:
                                        towerInfo.text = "Level " + castleLevelUi + "a" + " Castle";
                                        break;
                                    case 1:
                                        towerInfo.text = "Level " + castleLevelUi + "b" + " Castle";

                                        break;
                                }
                            }

                            healthText.text = "Health: " + castle.health + " / " + castle.maxHealth;
                            attackText.text = "Coin: +" + moneyCollector.coinGained + " / second";

                            fireRateText.gameObject.SetActive(false);
                            rangeText.gameObject.SetActive(false);
                            repairText.gameObject.SetActive(false);
                            deleteText.gameObject.SetActive(false);
                        }
                        else
                        {
                            towerInfo.text = "Castle";
                            healthText.text = "Health: ? / ?";
                            attackText.text = "Coin: ? / second";

                            upgradeText.text = "Press C to capture: " + upgrader.costToCapture +" Coin";

                            repairText.gameObject.SetActive(false);
                            deleteText.gameObject.SetActive(false);
                        }
                        break;

                    case 4:

                        castleManager mainCastle = selectedTower.GetComponent<castleManager>();
                        moneyManager moneyManager = selectedTower.GetComponent<moneyManager>();

                        if (mainCastle.health < mainCastle.maxHealth)
                        {
                            repairText.gameObject.SetActive(true);

                            repairText.text = "Kingdoms are irrepairable";
                        }
                        else
                        {
                            repairText.gameObject.SetActive(false);
                        }

                        if (mainCastle.construction)
                        {
                            upgradeText.text = "(Under Construction)";
                        }

                        towerLevel = mainCastle.level;

                        if (towerLevel == 0)
                        {
                            upgradeCost = upgrader.castUpgrade0Cost;
                            if (!mainCastle.construction)
                            {
                                upgradeText.gameObject.SetActive(true);
                                upgradeText.text = "F to upgrade: " + upgradeCost + " Coin";
                            }
                        }
                        else if (towerLevel == 1)
                        {
                            upgradeCost = upgrader.castUpgrade1Cost;
                            if (!mainCastle.construction)
                            {
                                upgradeText.gameObject.SetActive(true);
                                upgradeText.text = "F to upgrade: " + upgradeCost + " Coin";
                            }
                        }
                        else if (towerLevel == 2)
                        {
                            upgradeCost = upgrader.castUpgrade2Cost;
                            if (!mainCastle.construction)
                            {
                                upgradeText.gameObject.SetActive(true);
                                upgradeText.text = "5 or 6 to upgrade: " + upgradeCost + " Coin";
                            }
                        }


                        int mainCastleLevelUi;
                        int mainCastleAOrB = 0;

                        if (mainCastle.level + 1 < 4)
                            mainCastleLevelUi = mainCastle.level + 1;
                        else
                            mainCastleLevelUi = 4;

                        if (mainCastle.level == 3)
                            mainCastleAOrB = 0;
                        else if (mainCastle.level == 4)
                            mainCastleAOrB = 1;

                        if (mainCastle.level < 3)
                        {
                            towerInfo.text = "Level " + mainCastleLevelUi + " Kingdom";
                        }
                        else
                        {
                            upgradeText.text = "Fully upgraded";
                            switch (mainCastleAOrB)
                            {
                                case 0:
                                    towerInfo.text = "Level " + mainCastleLevelUi + "a" + " Kingdom";
                                    break;
                                case 1:
                                    towerInfo.text = "Level " + mainCastleLevelUi + "b" + " Kingdom";

                                    break;
                            }
                        }

                        healthText.text = "Health: " + mainCastle.health + " / " + mainCastle.maxHealth;
                        attackText.text = "Coin: +" + moneyManager.realCoin + " / second";
                        int ourMult = moneyManager.coinMultiplier - 1;
                        fireRateText.text = "Trade multiplier: " + ourMult;

                        rangeText.gameObject.SetActive(false);
                        break;
                }

                break;
        }
    }

    public void pressedBackingToggle()
    {
        if (statsBack)
        {
            statsBack = false;
        }
        else
        {
            statsBack = true;
        }
    }

    IEnumerator closeDelay()
    {
        Animator animat = selectorIcon.GetComponentInChildren<Animator>();
        animat.SetBool("closed", true);

        yield return new WaitForSeconds(.583f);

        animatedClose = true;
        animat.SetBool("closed", false);
    }
}
