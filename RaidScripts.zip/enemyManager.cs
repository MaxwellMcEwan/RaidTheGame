﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class enemyManager : MonoBehaviour
{
    enemySpawn spawnManager;

    GameObject mainCastle;
    startup start;

    public int gameState;

    bool settingUp;
    public bool spawning;

    bool countingNextRound;
    bool countingSpawnTime;

    bool spawnedForRound;
 
    public bool canSpawnTwin;

    bool gameReady;

    public int roundNum;

    GameObject[] spawners;

    public GameObject spawn0;
    public GameObject spawn1;
    public GameObject spawn2;
    public GameObject spawn3;
    public GameObject spawn4;
    public GameObject spawn5;

    public uiManager ui;
    // Start is called before the first frame update
    void Start()
    {
        int currentScene = SceneManager.GetActiveScene().buildIndex;
        if (currentScene < 6)
        {
            spawners = new GameObject[2];

            spawners[0] = spawn0;
            spawners[1] = spawn1;
            //spawners[2] = spawn2;
            //spawners[3] = spawn3;
            //spawners[4] = spawn4;
        } else if (currentScene >= 6 && currentScene < 13)
        {
            spawners = new GameObject[3];

            spawners[0] = spawn0;
            spawners[1] = spawn1;
            spawners[2] = spawn2;
            //spawners[3] = spawn3;
            //spawners[4] = spawn4;
        }
        else if(currentScene >= 13 && currentScene < 18)
        {
            spawners = new GameObject[4];

            spawners[0] = spawn0;
            spawners[1] = spawn1;
            spawners[2] = spawn2;
            spawners[3] = spawn3;
            //spawners[4] = spawn4;
        }
        else if(currentScene >= 18)
        {
            spawners = new GameObject[6];

            spawners[0] = spawn0;
            spawners[1] = spawn1;
            spawners[2] = spawn2;
            spawners[3] = spawn3;
            spawners[4] = spawn4;
            spawners[5] = spawn5;
        }


        roundNum = 0;

        mainCastle = GameObject.FindGameObjectWithTag("mainCastle");
        start = mainCastle.GetComponent<startup>();
        spawnManager = GetComponent<enemySpawn>();

        canSpawnTwin = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (!start.setup)
            return;

        spawnMachine();
    }

    void spawnMachine()
    {
        foreach (GameObject spawn in spawners)
        {
            enemySpawn enemySp = spawn.GetComponent<enemySpawn>();

            if (enemySp.triggered && !enemySp.activated)
            {
                //Creating new spawner
                enemySp.activated = true;
            }
        }
    }
}
