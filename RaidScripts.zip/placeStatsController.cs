﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class placeStatsController : MonoBehaviour
{
    public Text placingTower;
    public Text costText;

    public Text statUp;
    public Text healthText;
    public Text attackText;
    public Text fireRateText;
    public Text rangeText;

    public Image bookPageImg;

    Animator anim;

    public placeManager place;
    public pathPlaceManager pathPlace;

    int uiState;

    bool animatedClose;
    public static bool placeBackOption;

    // Start is called before the first frame update
    void Start()
    {
        placeBackOption = false;
        anim = GetComponent<Animator>();

        placingTower.gameObject.SetActive(false);
        costText.gameObject.SetActive(false);

        statUp.gameObject.SetActive(false);
        healthText.gameObject.SetActive(false);
        attackText.gameObject.SetActive(false);
        fireRateText.gameObject.SetActive(false);
        rangeText.gameObject.SetActive(false);

        bookPageImg.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (place.placing || pathPlace.placingCast)
        {
            uiState = 1;
        }
        else
        {
            uiState = 0;
        }

        uiSwitch();
    }

    void uiSwitch()
    {
        switch (uiState)
        {
            case 0:

                if (animatedClose == true)
                {
                    placingTower.gameObject.SetActive(false);
                    costText.gameObject.SetActive(false);

                    statUp.gameObject.SetActive(false);
                    healthText.gameObject.SetActive(false);
                    attackText.gameObject.SetActive(false);
                    fireRateText.gameObject.SetActive(false);
                    rangeText.gameObject.SetActive(false);

                    bookPageImg.gameObject.SetActive(false);
                }
                else
                {
                    anim.SetBool("open", false);
                    StartCoroutine(closeDelay());
                }

                break;

            case 1:

                animatedClose = false;

                anim.SetBool("open", true);

                placingTower.gameObject.SetActive(true);
                costText.gameObject.SetActive(true);

                statUp.gameObject.SetActive(true);
                healthText.gameObject.SetActive(true);
                attackText.gameObject.SetActive(true);
                fireRateText.gameObject.SetActive(true);
                rangeText.gameObject.SetActive(true);

                if (placeBackOption)
                {
                    bookPageImg.gameObject.SetActive(true);
                }
                else
                {
                    bookPageImg.gameObject.SetActive(false);
                }

                if (place.placing)
                {
                    switch (place.selectedTower)
                    {
                        case 0:
                            placingTower.text = "Placing: Lvl 1 Archer Tower";
                            costText.text = "Cost: " + place.archCost + " Coins";

                            healthText.text = "Max Health: 10";
                            attackText.text = "Attack: 2";
                            fireRateText.text = "Fire Rate: 3/sec";
                            rangeText.text = "Range: 30";

                            break;

                        case 1:
                            placingTower.text = "Placing: Lvl 1 Canon";
                            costText.text = "Cost: " + place.canonCost + " Coins";

                            healthText.text = "Max Health: 10";
                            attackText.text = "Attack: 7";
                            fireRateText.text = "Fire Rate: 5/sec";
                            rangeText.text = "Range: 35";
                            break;

                        case 2:
                            placingTower.text = "Placing: Lvl 1 Mage Tower";
                            costText.text = "Cost: " + place.mageCost + " Coins";

                            healthText.text = "Max Health: 15";
                            attackText.text = "Attack: 1";
                            fireRateText.text = "Fire Rate: 1/sec";
                            rangeText.text = "Range: 15";
                            break;

                        case 3:
                            placingTower.text = "Placing: Stone Wall";
                            costText.text = "Cost: " + place.wallCost + " Coins";

                            healthText.text = "Max Health: 10";
                            attackText.text = "It's a wall.";

                            fireRateText.gameObject.SetActive(false);
                            rangeText.gameObject.SetActive(false);

                            break;
                    }
                }
                else if (pathPlace.placingCast)
                {
                    placingTower.text = "Placing: Path";
                    costText.text = "Cost: " + pathPlace.pathCost + " Coin";

                    healthText.text = "Explore + trade";
                    attackText.text = "Press E to return";

                    fireRateText.gameObject.SetActive(false);
                    rangeText.gameObject.SetActive(false);
                }
                else
                {
                    uiState = 0;
                }

                break;
        }
    }

    public void pressedBackings()
    {
        if (placeBackOption)
        {
            placeBackOption = false;
        }
        else
        {
            placeBackOption = true;
        }
    }

    IEnumerator closeDelay()
    {
        yield return new WaitForSeconds(.583f);

        animatedClose = true;
    }
}
