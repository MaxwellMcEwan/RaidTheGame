﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gridSnap : MonoBehaviour
{
    private Grid gGrid;

    // Start is called before the first frame update
    void Start()
    {
        gGrid = Grid.FindObjectOfType<Grid>();
    }

    // Late Update is called late once per frame
    private void LateUpdate()
    {
        Vector3Int cp = gGrid.LocalToCell(transform.localPosition);
        transform.localPosition = gGrid.GetCellCenterLocal(cp);
    }
}
