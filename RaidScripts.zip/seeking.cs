﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class seeking : MonoBehaviour
{
    int ourType;
    float ourRadius;

    public GameObject ourSpotlight;
    Vector3 spotlightPosistion;
    // Start is called before the first frame update
    void Awake()
    {
        findOurType();
    }

    private void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        switch (ourType)
        {
            case 0:
                archerTower archer = GetComponent<archerTower>();

                ourRadius = archer.lookRadius;

                break;

            case 1:
                canonTower canon = GetComponent<canonTower>();

                ourRadius = canon.lookRadius;

                break;

            case 2:
                mageTower mage = GetComponent<mageTower>();

                ourRadius = mage.lookRadius;

                break;

            case 3:
                castleManager castle = GetComponent<castleManager>();

                ourRadius = castle.lookRadius;

                break;
        }
    }

    void findOurType()
    {
        if (GetComponent<archerTower>() != null)
        {
            ourType = 0;
        }
        else if (GetComponent<canonTower>() != null)
        {
            ourType = 1;
        }
        else if (GetComponent<mageTower>() != null)
        {
            ourType = 2;
        }
        else if (GetComponent<moneyManager>() != null)
        {
            ourType = 3;
        }
        else if (GetComponent<moneyCollector>() != null)
        {
            ourType = 4;
        }
    }
}
