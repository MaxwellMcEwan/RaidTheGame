﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class mageController : MonoBehaviour
{
    public GameObject mage;
    GameObject mainCastle;

    float lookRadius = 30;
    float attackRadius = 20;

    GameObject ourMage;
    NavMeshAgent agent;

    startup start;

    int towerType;
    public int targetType;

    GameObject target;
    GameObject closestTower;
    GameObject closestCastle;

    float attackCooldown = 3;
    public bool attackCooling;

    float towerDist;
    float castleDist;

    bool collidedWall;

    public float health;
    float maxHealth;

    int damage;

    public bool died;
    public bool casting;

    public GameObject graveStone;
    public GameObject bloodSplatter;

    enemyAnimationController animationController;
    private void Awake()
    {
        ourMage = Instantiate(mage, transform);

        mainCastle = GameObject.FindGameObjectWithTag("mainCastle");
    }

    // Start is called before the first frame update
    void Start()
    {
        damage = 5;
        maxHealth = 25;
        health = maxHealth;

        agent = GetComponent<NavMeshAgent>();
        start = mainCastle.GetComponent<startup>();
        animationController = GetComponent<enemyAnimationController>();

        FindClosestCastle();
        FindClosestTower();
    }

    // Update is called once per frame
    void Update()
    {
        if (!died)
        {
            if (health <= 0)
            {
                die();
                return;
            }
            else if (animationController.stunned)
            {
                if (agent.isOnNavMesh)
                    agent.isStopped = true;

                return;
            }
            else if (mainCastle != null)
                findTarget();
        }
    }

    void findTarget()
    {
        if (!collidedWall)
        {
            if (closestCastle != null)
                castleDist = Vector3.Distance(closestCastle.transform.position, transform.position);

            if (closestTower != null)
            {
                towerDist = Vector3.Distance(closestTower.transform.position, transform.position);

                if (castleDist < towerDist)
                {
                    targetType = 0;
                }
                else if (castleDist > towerDist && towerDist <= lookRadius)
                {
                    targetType = 1;
                }

                approachTarget();
            }
            else
            {
                targetType = 0;
                approachTarget();

                FindClosestTower();
            }
        }
        else
        {
            if (target == null)
            {
                collidedWall = false;
            }
            else
            {
                agent.isStopped = true;

                towerType = 3;
                attack();
            }
        }
    }

    void approachTarget()
    {
        switch (targetType)
        {
            case 0:

                target = closestCastle;

                if (castleDist <= attackRadius)
                {
                    casting = true;
                    attack();

                    agent.isStopped = true;
                }
                else
                {
                    casting = false;
                    agent.isStopped = false;

                    agent.SetDestination(target.transform.position);
                }

                break;

            case 1:

                target = closestTower;

                if (towerDist <= attackRadius)
                {
                    casting = true;
                    attack();

                    agent.isStopped = true;
                }
                else
                {
                    casting = false;
                    agent.isStopped = false;

                    agent.SetDestination(target.transform.position);
                }

                break;
        }
    }

    public void FindClosestTower()
    {
        GameObject[] gos;
        gos = GameObject.FindGameObjectsWithTag("tower");

        closestTower = null;
        float distance = Mathf.Infinity;
        Vector3 position = transform.position;
        foreach (GameObject go in gos)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance)
            {
                closestTower = go;
                distance = curDistance;
            }
        }
    }

    public void FindClosestCastle()
    {
        GameObject[] castles;
        castleManager[] attacks;
        attacks = FindObjectsOfType<castleManager>();

        castles = new GameObject[attacks.Length];
        for (int i = 0; i < castles.Length; i++)
            castles[i] = attacks[i].gameObject;

        closestCastle = null;
        float distance = Mathf.Infinity;
        Vector3 position = transform.position;
        foreach (GameObject go in castles)
        {
            Vector3 diff = go.transform.position - position;
            float curDistance = diff.sqrMagnitude;
            if (curDistance < distance)
            {
                if (go.tag != "maincastle")
                {
                    if (go.GetComponent<captureCastleCont>().exposed && go.GetComponent<captureCastleCont>().captured)
                    {
                        closestCastle = go;
                        distance = curDistance;
                    }
                }
                else
                {
                    closestCastle = go;
                    distance = curDistance;
                }
            }
        }
    }


    void attack()
    {
        AudioSource source = GetComponent<AudioSource>();

        if (!attackCooling)
        {
            if (target == closestTower && target != null)
            {
                if (target.GetComponent<archerTower>() != null)
                {
                    //archer
                    towerType = 0;
                }
                else if (target.GetComponent<canonTower>() != null)
                {
                    //canon
                    towerType = 1;
                }
                else if (target.GetComponent<mageTower>() != null)
                {
                    //mage
                    towerType = 2;
                }
            }
            else if (target == closestCastle && target != null)
            {
                if (target.GetComponent<startup>() != null)
                {
                    //main castle
                    towerType = 5;
                }
                else if (target.GetComponent<captureCastleCont>() != null)
                {
                    //castle
                    towerType = 4;
                }
            }

            source.Play();

            FindClosestCastle();
            FindClosestTower();

            switch (towerType)
            {
                case 0:
                    archerTower archer = target.GetComponent<archerTower>();

                    if (archer.gameObject != null)
                    {
                        archer.health -= damage;
                        archer.StartCoroutine(archer.recentlyHitTimer());
                    }
                    break;

                case 1:

                    canonTower canon = target.GetComponent<canonTower>();

                    if (canon.gameObject != null)
                    {
                        canon.health -= damage;
                        canon.StartCoroutine(canon.recentlyHitTimer());
                    }

                    break;

                case 2:

                    mageTower mage = target.GetComponent<mageTower>();

                    if (mage.gameObject != null)
                    {
                        mage.health -= damage;
                        mage.StartCoroutine(mage.recentlyHitTimer());
                    }

                    break;

                case 3:

                    wallController wall = target.GetComponent<wallController>();

                    if (wall.gameObject != null)
                    {

                        gameObject.transform.LookAt(target.transform);
                        wall.health -= damage;
                    }
                    break;

                case 4:
                    if (target != null)
                    {
                        castleManager castle = target.GetComponent<castleManager>();

                        if (castle.gameObject != null)
                        {
                            castle.health -= 3;
                        }
                    }

                    break;

                case 5:
                    castleManager castleMain = mainCastle.GetComponent<castleManager>();

                    if (castleMain.gameObject != null)
                    {
                        castleMain.health -= 3;
                    }

                    break;
            }

            StartCoroutine(attackCool());
        }
    }

    void die()
    {
        died = true;
        FindObjectOfType<audioManager>().play("bellDing");

        lightManager lightMan = FindObjectOfType<lightManager>();
        lightMan.totalKills += 1;
        lightMan.updateKills();

        StartCoroutine(deleteDelay());
    }

    IEnumerator deleteDelay()
    {
        NavMeshAgent agent = GetComponent<NavMeshAgent>();
        CapsuleCollider capsule = GetComponent<CapsuleCollider>();

        agent.enabled = false;
        capsule.enabled = false;

        gameObject.tag = "mound";

        yield return new WaitForSeconds(8);

        Destroy(gameObject);
    }

    IEnumerator attackCool()
    {
        attackCooling = true;

        yield return new WaitForSeconds(attackCooldown);

        attackCooling = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "wall")
        {
            collidedWall = true;

            target = other.gameObject;
        }
    }
}
