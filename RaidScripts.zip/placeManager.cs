﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class placeManager : MonoBehaviour
{
    moneyManager money;
    startup start;

    Camera cam;

    public int archCost = 20;
    public int canonCost = 30;
    public int mageCost = 45;
    public int wallCost = 4;

    public GameObject archTowerController;
    public GameObject canonTowerController;
    public GameObject mageTowerController;
    public GameObject towerPrefab;
    public GameObject wallPrefab;

    public GameObject wallCont;

    public towerSelector selector;
    public bool placing;
    public int selectedTower;

    public pathPlaceManager castlePlaceMan;

    public GameObject archSelected;
    public GameObject canonSelected;
    public GameObject mageSelected;
    public GameObject wallSelected;

    GameObject towerSelectGo;

    public bool tooPoor;
    public bool selectedColliding;
    bool playedPlace;

    int form;
    int wallDir;
    bool rotated0;
    bool rotated1;

    //0: Archer
    //1: Cannon
    //2: Mage

    KeyCode placingPathKey = KeyCode.Q;
    KeyCode placingTow = KeyCode.X;

    KeyCode placingArchKey = KeyCode.Alpha1;
    KeyCode placingCanKey = KeyCode.Alpha2;
    KeyCode placingMageKey = KeyCode.Alpha3;
    KeyCode placingWallKey = KeyCode.Alpha4;

    // Start is called before the first frame update
    void Start()
    {
        rotated0 = true;
        rotated1 = false;

        towerSelectGo = selector.gameObject;

        cam = Camera.main;

        start = GetComponent<startup>();
        money = GetComponent<moneyManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!start.setup)
            return;

        if (placing)
        {
            if (!playedPlace)
            {
                playedPlace = true;
                FindObjectOfType<audioManager>().play("placing");
            }

            towerSelectGo.SetActive(true);

            if (Input.GetKeyUp(placingPathKey) || Input.GetKeyDown(placingTow) || Input.GetMouseButtonDown(1))
            {
                placing = false;
                playedPlace = false;
            }

            Place();
        }
        else
        {
            towerSelectGo.SetActive(false);

            if (Input.GetKeyDown(placingTow) || Input.GetKey(placingArchKey) || Input.GetKey(placingCanKey) || Input.GetKey(placingMageKey) || Input.GetKey(placingWallKey) || Input.GetMouseButtonDown(1))
            {
                placing = true;
                if (Input.GetKeyUp(placingArchKey))
                {
                    selector.selectedTower = 0;
                } else if (Input.GetKeyUp(placingCanKey))
                {
                    selector.selectedTower = 1;

                } else if (Input.GetKeyUp(placingMageKey))
                {
                    selector.selectedTower = 2;
                } else if (Input.GetKeyUp(placingWallKey))
                {
                    selector.selectedTower = 3;
                }
            }
        }
    }

    void Place()
    {
        if (placing)
        {
            switch (selectedTower)
            {
                case 0:
                    if (Input.GetKeyUp(KeyCode.R))
                        selector.towerOpen.Rotate(0, 90, 0);

                    collisionCheck arcCollision = selector.transform.GetChild(0).gameObject.GetComponent<collisionCheck>();

                    if (money.coin < archCost)
                    {
                        arcCollision.underCount = true;
                    }
                    else
                    {
                        arcCollision.underCount = false;
                    }

                    if (Input.GetMouseButtonUp(0))
                    {
                        if (!archSelected.GetComponent<collisionCheck>().colliding)
                        {
                            if (money.coin >= archCost)
                            {
                                money.coin -= archCost;

                                GameObject archTowerCont = Instantiate(archTowerController, selector.towerOpen.position, selector.towerOpen.rotation);
                                archerTower archerTower = archTowerCont.GetComponent<archerTower>();

                                archerTower.StartCoroutine(archerTower.upgrade0());

                                int randomPlay = Random.Range(0, 3);
                                switch (randomPlay)
                                {
                                    case 0:
                                        FindObjectOfType<audioManager>().play("buildWood0");
                                        break;

                                    case 1:
                                        FindObjectOfType<audioManager>().play("buildWood1");

                                        break;

                                    case 2:
                                        FindObjectOfType<audioManager>().play("buildWood2");
                                        break;
                                }
                            }
                            else
                            {
                                tooPoor = true;
                            }
                        }
                        else
                        {
                            selectedColliding = true;
                        }
                    }

                    break;

                case 1:

                    collisionCheck canCollision = selector.transform.GetChild(1).gameObject.GetComponent<collisionCheck>();

                    if (money.coin < canonCost)
                    {
                        canCollision.underCount = true;
                    }
                    else
                    {
                        canCollision.underCount = false;
                    }

                    if (Input.GetMouseButtonUp(0))
                    {
                        if (!canonSelected.GetComponent<collisionCheck>().colliding)
                        {
                            if (money.coin >= canonCost)
                            {
                                money.coin -= canonCost;

                                GameObject canonTowerCont = Instantiate(canonTowerController, selector.towerOpen.position, selector.towerOpen.rotation);
                                canonTower canonTower = canonTowerCont.GetComponent<canonTower>();

                                canonTower.StartCoroutine(canonTower.upgrade0());

                                int randomPlay = Random.Range(0, 3);
                                switch (randomPlay)
                                {
                                    case 0:
                                        FindObjectOfType<audioManager>().play("buildWood0");
                                        break;

                                    case 1:
                                        FindObjectOfType<audioManager>().play("buildWood1");

                                        break;

                                    case 2:
                                        FindObjectOfType<audioManager>().play("buildWood2");
                                        break;
                                }
                            }
                            else
                            {
                                tooPoor = true;
                            }
                        }
                        else
                        {
                            selectedColliding = true;
                        }
                    }

                    break;

                case 2:
                    collisionCheck magCollision = selector.transform.GetChild(2).gameObject.GetComponent<collisionCheck>();

                    if (money.coin < mageCost)
                    {
                        magCollision.underCount = true;
                    }
                    else
                    {
                        magCollision.underCount = false;
                    }

                    if (Input.GetMouseButtonUp(0))
                    {
                        if (!mageSelected.GetComponent<collisionCheck>().colliding)
                        {
                            if (money.coin >= mageCost)
                            {
                                money.coin -= mageCost;

                                GameObject mageTowerCont = Instantiate(mageTowerController, selector.towerOpen.position, selector.towerOpen.rotation);
                                mageTower mageTower = mageTowerCont.GetComponent<mageTower>();

                                mageTower.StartCoroutine(mageTower.upgrade0());

                                int randomPlay = Random.Range(0, 3);
                                switch (randomPlay)
                                {
                                    case 0:
                                        FindObjectOfType<audioManager>().play("buildWood0");
                                        break;

                                    case 1:
                                        FindObjectOfType<audioManager>().play("buildWood1");

                                        break;

                                    case 2:
                                        FindObjectOfType<audioManager>().play("buildWood2");
                                        break;
                                }
                            }
                            else
                            {
                                tooPoor = true;
                            }
                        }
                        else
                        {
                            selectedColliding = true;
                        }
                    }

                    break;

                case 3:
                    collisionCheck wallCollider = wallSelected.GetComponent<collisionCheck>();

                    if (money.coin < wallCost)
                    {
                        wallCollider.underCount = true;
                    }
                    else
                    {
                        wallCollider.underCount = false;
                    }

                    if (Input.GetKeyUp(KeyCode.R))
                    {
                        if (wallDir == 1)
                            wallDir = 0;
                        else if (wallDir == 0)
                            wallDir = 1;
                    }

                    switch (wallDir)
                    {
                        case 0:
                            if (!rotated0)
                            {
                                selector.towerOpen.Rotate(0, -90, 0);
                                rotated1 = false;
                                rotated0 = true;
                            }

                            break;
                        case 1:

                            if (!rotated1)
                            {
                                rotated1 = true;
                                rotated0 = false;
                                selector.towerOpen.Rotate(0, 90, 0);
                            }

                            break;
                    }

                    if (Input.GetMouseButtonUp(0))
                    {
                        if (!wallCollider.colliding)
                        {
                            if (money.coin >= wallCost)
                            {
                                money.coin -= wallCost;

                                switch (selector.wallForm)
                                {
                                    case 0:
                                        GameObject wall = Instantiate(wallCont, selector.towerOpen.position, selector.towerOpen.rotation);
                                        wallController controller0 = wall.GetComponent<wallController>();

                                        controller0.spawnOurselves(wallPrefab, 0);
                                        break;
                                    case 1:
                                        GameObject tower = Instantiate(wallCont, selector.towerOpen.position, selector.towerOpen.rotation);
                                        wallController controller1 = tower.GetComponent<wallController>();

                                        controller1.spawnOurselves(towerPrefab, 1);
                                        break;

                                }
                                int randomPlay = Random.Range(0, 2);
                                switch (randomPlay)
                                {
                                    case 0:
                                        FindObjectOfType<audioManager>().play("buildStone0");
                                        break;

                                    case 1:
                                        FindObjectOfType<audioManager>().play("buildStone1");
                                        break;
                                }
                                break;

                            }
                            else
                            {
                                tooPoor = true;
                            }
                        }
                    }

                    break;
            }
        }
    }
}
