﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

[System.Serializable]
public class sound
{
    public string name;

    public AudioClip clip;

    [Range(0,1f)]
    public float volume;
    [Range(.1f, 3)]
    public float pitch;
    public bool spatial = true;

    [HideInInspector]
    public AudioSource source;

    public string outputGroup;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
