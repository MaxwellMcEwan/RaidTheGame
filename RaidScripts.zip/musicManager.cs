﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
using System.Linq;
using Random = UnityEngine.Random;

public class musicManager : MonoBehaviour
{
    public music[] musics;
    public string[] playlist;

    public static musicManager instance;
    Animator musicFades;

    public int ourBuildIndex;
    bool playingMusic;

    AudioSource ourSource;

    float timeBetweenTracks = 2;

    int currentSong;
    // Start is called before the first frame update
    void Awake()
    {
        playingMusic = false;
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);
        musicFades = gameObject.GetComponent<Animator>();
        ourSource = gameObject.GetComponent<AudioSource>();
    }

    private void Start()
    {
        playlist = new string[6];
        playlist[0] = "birdAmb0";
        playlist[1] = "village";
        playlist[2] = "spring";
        playlist[3] = "cave";
        playlist[4] = "castle";
        playlist[5] = "trailerMusic";
    }

    // Update is called once per frame
    void Update()
    {
        if (!playingMusic)
        {
            shufflePlaylist(playlist);
        }
    }

    public void fadeOutAudio()
    {
        musicFades.SetTrigger("fadeOut");
    }

    public void fadeInAudio()
    {
        musicFades.ResetTrigger("fadeOut");
        musicFades.Play("musicFadeIn", -1, 0f);
    }

    public void Play(string name)
    {
        music m = Array.Find(musics, music => music.name == name);
        ourSource.clip = m.track;
        ourSource.Play();

        StartCoroutine(songLengthDelay(ourSource.clip.length));
    }

    IEnumerator songLengthDelay(float length)
    {

        yield return new WaitForSeconds(length - 4);
        fadeOutAudio();
        yield return new WaitForSeconds(timeBetweenTracks + 4);
        playingMusic = false;
        ourBuildIndex = SceneManager.GetActiveScene().buildIndex;
    }

    void shufflePlaylist(string[] avaliable)
    {
        playingMusic = true;
        fadeInAudio();

        Play(avaliable[currentSong]);

        if (currentSong < avaliable.Length -1)
            currentSong += 1;
        else
        {
            currentSong = 0;
        }
    }
}
